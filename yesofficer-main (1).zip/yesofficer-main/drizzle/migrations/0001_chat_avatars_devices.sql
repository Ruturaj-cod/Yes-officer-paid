ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS avatar_url text NOT NULL DEFAULT '';

CREATE TABLE public.login_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  username text not null default '',
  device text not null default '',
  user_agent text not null default '',
  ip text not null default '',
  created_at timestamptz not null default now()
);
GRANT SELECT ON public.login_devices TO authenticated;
GRANT ALL ON public.login_devices TO service_role;
ALTER TABLE public.login_devices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "owner reads devices" ON public.login_devices FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  username text not null default '',
  display_name text not null default '',
  avatar_url text not null default '',
  is_admin boolean not null default false,
  body text not null default '',
  media_url text not null default '',
  media_type text not null default '',
  created_at timestamptz not null default now()
);
GRANT SELECT ON public.chat_messages TO authenticated;
GRANT ALL ON public.chat_messages TO service_role;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members read chat" ON public.chat_messages FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND NOT p.suspended));
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;

CREATE TABLE public.chat_restrictions (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  banned boolean not null default false,
  block_text boolean not null default false,
  block_emoji boolean not null default false,
  block_image boolean not null default false,
  block_video boolean not null default false,
  block_audio boolean not null default false,
  updated_at timestamptz not null default now()
);
GRANT SELECT ON public.chat_restrictions TO authenticated;
GRANT ALL ON public.chat_restrictions TO service_role;
ALTER TABLE public.chat_restrictions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own or owner reads restrictions" ON public.chat_restrictions FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "members upload own files" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id IN ('avatars','chat') AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "members update own files" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id IN ('avatars','chat') AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "members read files" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id IN ('avatars','chat') AND EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND NOT p.suspended));