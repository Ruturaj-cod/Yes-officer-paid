CREATE TABLE public.cached_content (
  course_id text NOT NULL,
  item_id text NOT NULL,
  kind text NOT NULL DEFAULT 'VIDEO',
  title text NOT NULL DEFAULT '',
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (course_id, item_id, kind)
);
GRANT SELECT, INSERT, UPDATE ON public.cached_content TO authenticated;
GRANT ALL ON public.cached_content TO service_role;
ALTER TABLE public.cached_content ENABLE ROW LEVEL SECURITY;
CREATE POLICY "members read cache" ON public.cached_content FOR SELECT TO authenticated USING (true);
CREATE POLICY "members add cache" ON public.cached_content FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "members refresh cache" ON public.cached_content FOR UPDATE TO authenticated USING (true) WITH CHECK (true);