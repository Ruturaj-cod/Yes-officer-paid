create type public.app_role as enum ('admin', 'user');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  display_name text not null default '',
  suspended boolean not null default false,
  active_session_id text,
  created_at timestamptz not null default now()
);
grant select on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

create policy "own or admin read profiles" on public.profiles for select to authenticated
  using (id = auth.uid() or public.has_role(auth.uid(), 'admin'));
create policy "own or admin read roles" on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

create table public.batch_access (
  user_id uuid not null references public.profiles(id) on delete cascade,
  course_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, course_id)
);
grant select on public.batch_access to authenticated;
grant all on public.batch_access to service_role;
alter table public.batch_access enable row level security;
create policy "own or admin read access" on public.batch_access for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

create table public.access_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  username text not null default '',
  course_id text not null default '',
  item_id text not null default '',
  item_title text not null default '',
  kind text not null default '',
  created_at timestamptz not null default now()
);
create index access_logs_created_idx on public.access_logs (created_at desc);
grant select on public.access_logs to authenticated;
grant all on public.access_logs to service_role;
alter table public.access_logs enable row level security;
create policy "admin read logs" on public.access_logs for select to authenticated
  using (public.has_role(auth.uid(), 'admin'));