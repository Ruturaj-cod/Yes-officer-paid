DROP POLICY IF EXISTS "active members add cache" ON public.cached_content;
DROP POLICY IF EXISTS "active members refresh cache" ON public.cached_content;
CREATE POLICY "active members add cache" ON public.cached_content FOR INSERT TO authenticated
  WITH CHECK (kind IN ('VIDEO','PDF','TEST','FOLDER') AND EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND NOT p.suspended)
    AND (public.has_role(auth.uid(),'admin') OR EXISTS (SELECT 1 FROM public.batch_access b WHERE b.user_id = auth.uid() AND b.course_id = cached_content.course_id)));
CREATE POLICY "active members refresh cache" ON public.cached_content FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR EXISTS (SELECT 1 FROM public.batch_access b WHERE b.user_id = auth.uid() AND b.course_id = cached_content.course_id))
  WITH CHECK (kind IN ('VIDEO','PDF','TEST','FOLDER') AND EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND NOT p.suspended)
    AND (public.has_role(auth.uid(),'admin') OR EXISTS (SELECT 1 FROM public.batch_access b WHERE b.user_id = auth.uid() AND b.course_id = cached_content.course_id)));