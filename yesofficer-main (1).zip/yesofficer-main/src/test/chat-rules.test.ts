import { describe, expect, it } from "vitest";
import { chatBlockReason, type ChatRules } from "@/lib/access";

const none: ChatRules = { banned: false, block_text: false, block_emoji: false, block_image: false, block_video: false, block_audio: false };

describe("chat restrictions", () => {
  it("banned users can't send anything", () => {
    expect(chatBlockReason({ ...none, banned: true }, { body: "hi", mediaType: "" })).not.toBe("");
  });
  it("emoji block stops emoji but allows text", () => {
    const r = { ...none, block_emoji: true };
    expect(chatBlockReason(r, { body: "hello 😀", mediaType: "" })).not.toBe("");
    expect(chatBlockReason(r, { body: "hello", mediaType: "" })).toBe("");
  });
  it("text block stops words", () => {
    expect(chatBlockReason({ ...none, block_text: true }, { body: "hello", mediaType: "" })).not.toBe("");
  });
  it("video and audio blocks stop those uploads", () => {
    expect(chatBlockReason({ ...none, block_video: true }, { body: "", mediaType: "video" })).not.toBe("");
    expect(chatBlockReason({ ...none, block_audio: true }, { body: "", mediaType: "audio" })).not.toBe("");
    expect(chatBlockReason({ ...none, block_video: true }, { body: "", mediaType: "image" })).toBe("");
  });
  it("owner is never restricted", () => {
    expect(chatBlockReason({ ...none, banned: true }, { body: "x", mediaType: "video" }, true)).toBe("");
  });
});
