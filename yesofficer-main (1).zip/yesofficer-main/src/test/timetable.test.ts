import { describe, expect, it } from "vitest";
import { timetableDateKey, timetableForBatches, type TimetableItem } from "@/lib/timetable";

const item = (courseId: string): TimetableItem => ({ id: "36795", courseId, batchTitle: "", title: "Class 02: Profit Loss", type: "VIDEO", thumbnail: "", pdfs: [], fileUrl: "", time: 1791855000, upcoming: false, live: true });
describe("timetable", () => {
  it("only includes classes from assigned batches", () => {
    expect(timetableForBatches([item("297"), item("286")], [{ id: "297", title: "Operation Mains", thumbnail: "" }]).map((x) => x.courseId)).toEqual(["297"]);
  });
  it("uses India date when grouping a class near UTC midnight", () => {
    expect(timetableDateKey(Date.parse("2026-10-13T23:30:00Z") / 1000)).toBe("2026-10-14");
  });
});