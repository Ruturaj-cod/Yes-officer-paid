import { describe, expect, it } from "vitest";
import { parseTest } from "@/lib/yoapi";

describe("parseTest", () => {
  it("parses questions with options array and 1-based correct_option", () => {
    const t = parseTest("22877", {
      title: "Mock Test on Mixed Topics 10.0",
      time_in_mins: 20,
      total_marks: 50,
      questions: [
        { id: 1, question: "<p>2 + 2 = ?</p>", options: ["3", "4", "5", "6"], correct_option: 2 },
        { id: 2, question: "<p>Capital of India?</p>", options: ["Mumbai", "Delhi"], correct_option: 2 },
      ],
    });
    expect(t.id).toBe("22877");
    expect(t.title).toBe("Mock Test on Mixed Topics 10.0");
    expect(t.minutes).toBe(20);
    expect(t.totalMarks).toBe(50);
    expect(t.questions).toHaveLength(2);
    expect(t.questions[0]).toMatchObject({ html: "<p>2 + 2 = ?</p>", options: ["3", "4", "5", "6"], answer: 2 });
  });

  it("parses option_1..option_4 fields and answer variants", () => {
    const t = parseTest("1", {
      test_title: "T",
      duration: "10",
      question_list: [{ question_title: "Q1", option_1: "a", option_2: "b", option_3: "c", answer: "3" }],
    });
    expect(t.minutes).toBe(10);
    expect(t.questions[0]!.options).toEqual(["a", "b", "c"]);
    expect(t.questions[0]!.answer).toBe(3);
  });

  it("marks out-of-range answers as unknown (0) so scoring skips them", () => {
    const t = parseTest("1", { questions: [{ question: "Q", options: ["a", "b"], correct_option: 9 }] });
    expect(t.questions[0]!.answer).toBe(0);
  });

  it("drops empty questions", () => {
    const t = parseTest("1", { questions: [{ question: "", options: [] }, { question: "Real", options: ["x"] }] });
    expect(t.questions).toHaveLength(1);
  });

  it("treats a numeric questions count as metadata, not questions", () => {
    const t = parseTest("22877", { title: "Mock", time_in_mins: 20, questions: "30" });
    expect(t.questions).toHaveLength(0);
    expect(t.minutes).toBe(20);
  });

  it("merges metadata with a fetched questions file payload", () => {
    const meta = { title: "Mock Test", time_in_mins: 20, total_marks: 50, questions: "30" };
    const file = { questions: [{ id: 7, question: "<p>Q?</p>", options: ["a", "b"], correct_option: 1 }] };
    const t = parseTest("22877", { ...meta, ...file, questions: file.questions });
    expect(t.title).toBe("Mock Test");
    expect(t.minutes).toBe(20);
    expect(t.questions[0]).toMatchObject({ id: "7", answer: 1 });
  });
});
