import { describe, it, expect, vi } from "vitest";
vi.mock("@/lib/auth.functions", () => ({ getApiToken: vi.fn() }));
import { liveState } from "@/lib/yoapi";

const now = 1_800_000_000_000;
const at = (offsetMs: number) => ({ live_status: 1, strtotime: (now + offsetMs) / 1000 });

describe("liveState", () => {
  it("future scheduled lecture is upcoming", () => {
    expect(liveState("VIDEO", at(3600_000), now)).toEqual({ upcoming: true, live: false });
  });
  it("lecture started 30 minutes ago is live now", () => {
    expect(liveState("VIDEO", at(-1800_000), now)).toEqual({ upcoming: false, live: true });
  });
  it("lecture started 5 hours ago is no longer live", () => {
    expect(liveState("VIDEO", at(-5 * 3600_000), now)).toEqual({ upcoming: false, live: false });
  });
  it("normal recorded video is neither", () => {
    expect(liveState("VIDEO", { live_status: 0, strtotime: now / 1000 }, now)).toEqual({ upcoming: false, live: false });
  });
  it("Yes Officer status 3 marks an active class live", () => {
    expect(liveState("VIDEO", { live_status: 3, strtotime: (now - 3600_000) / 1000 }, now)).toEqual({ upcoming: false, live: true });
  });
  it("status 3 class from months ago is not live", () => {
    expect(liveState("VIDEO", { live_status: 3, strtotime: (now - 90 * 86400_000) / 1000 }, now)).toEqual({ upcoming: false, live: false });
  });
  it("status 3 without a start time is not live", () => {
    expect(liveState("VIDEO", { live_status: 3 }, now)).toEqual({ upcoming: false, live: false });
  });
});
