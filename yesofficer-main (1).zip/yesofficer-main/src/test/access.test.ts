import { describe, expect, it } from "vitest";
import { canOpenBatch, deviceStatus, visibleBatches } from "@/lib/access";

const batches = [{ id: "252" }, { id: "253" }, { id: "260" }];

describe("batch access", () => {
  it("students only see assigned batches", () => {
    expect(visibleBatches(batches, ["253"], false).map((b) => b.id)).toEqual(["253"]);
  });
  it("owner sees all batches", () => {
    expect(visibleBatches(batches, [], true)).toHaveLength(3);
  });
  it("blocks opening an unassigned batch", () => {
    expect(canOpenBatch("260", ["253"], false)).toBe(false);
  });
});

describe("one device per account", () => {
  it("older device is replaced after a new sign-in", () => {
    expect(deviceStatus({ suspended: false, active_session_id: "new" }, "old")).toBe("replaced");
  });
  it("current device stays signed in", () => {
    expect(deviceStatus({ suspended: false, active_session_id: "new" }, "new")).toBe("ok");
  });
  it("suspended account is blocked", () => {
    expect(deviceStatus({ suspended: true, active_session_id: "new" }, "new")).toBe("suspended");
  });
});
