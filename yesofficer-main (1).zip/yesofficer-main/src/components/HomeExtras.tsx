import { Link } from "@tanstack/react-router";
import { useQueries } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { CalendarClock, FileText, Folder, PlayCircle, Sparkles, History } from "lucide-react";
import { fetchBatchIndex, type Batch, type IndexedItem } from "@/lib/yoapi";
import { formatLectureTime, getLastWatched, type LastWatched } from "@/lib/progress";

export function ContinueLearning({ allowed }: { allowed: Set<string> | null }) {
  const [list, setList] = useState<LastWatched[]>([]);
  useEffect(() => setList(getLastWatched()), []);
  const shown = list.filter((x) => !allowed || allowed.has(x.courseId)).slice(0, 6);
  if (!shown.length) return null;
  return (
    <section>
      <h2 className="mb-3 flex items-center gap-2 text-sm font-extrabold"><History className="h-4 w-4 text-primary" /> Continue learning</h2>
      <div className="flex gap-3 overflow-x-auto pb-2">
        {shown.map((x) => {
          const pct = x.duration ? Math.min(100, Math.round((x.position / x.duration) * 100)) : 0;
          return (
            <Link key={x.videoId} to="/batch/$courseId/video/$videoId" params={{ courseId: x.courseId, videoId: x.videoId }} search={{ t: x.title }} className="w-60 shrink-0 rounded-xl border border-border bg-card p-3 shadow-card hover:border-primary">
              <p className="line-clamp-2 text-sm font-semibold">{x.title}</p>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted"><div className="h-full bg-accent" style={{ width: `${pct}%` }} /></div>
              <p className="mt-1 text-[11px] text-muted-foreground">{pct ? `${pct}% watched` : "Resume"}</p>
            </Link>
          );
        })}
      </div>
    </section>
  );
}

function ItemLink({ it, batchTitle }: { it: IndexedItem; batchTitle: string }) {
  const sub = [batchTitle, ...it.path.map((p) => p.t)].join(" › ");
  const Icon = it.type === "VIDEO" ? PlayCircle : it.type === "FOLDER" ? Folder : FileText;
  const body = (
    <>
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-secondary text-primary"><Icon className="h-4 w-4" /></span>
      <span className="min-w-0 flex-1">
        <span className="line-clamp-1 text-sm font-semibold">{it.title}</span>
        <span className="line-clamp-1 text-[11px] text-muted-foreground">{it.time ? `${formatLectureTime(it.time)} · ` : ""}{sub}</span>
      </span>
    </>
  );
  const cls = "flex items-center gap-3 rounded-xl border border-border bg-card p-2.5 hover:border-primary";
  if (it.type === "VIDEO") return <Link to="/batch/$courseId/video/$videoId" params={{ courseId: it.courseId, videoId: it.id }} search={{ t: it.title }} className={cls}>{body}</Link>;
  if (it.type === "FOLDER") {
    const trail = [...it.path, { id: it.id, t: it.title }];
    return <Link to="/batch/$courseId" params={{ courseId: it.courseId }} search={{ parent: it.id, trail: JSON.stringify(trail) }} className={cls}>{body}</Link>;
  }
  return <Link to="/batch/$courseId" params={{ courseId: it.courseId }} search={{ parent: it.parentId === "-1" ? undefined : it.parentId, trail: it.path.length ? JSON.stringify(it.path) : undefined }} className={cls}>{body}</Link>;
}

/** Upcoming, recently added and search across every assigned batch. */
export function Discover({ batches, q }: { batches: Batch[]; q: string }) {
  const results = useQueries({
    queries: batches.map((b) => ({ queryKey: ["batch-index", b.id], queryFn: () => fetchBatchIndex(b.id), staleTime: 15 * 60_000 })),
  });
  const loading = results.some((r) => r.isLoading);
  const titles = useMemo(() => new Map(batches.map((b) => [b.id, b.title])), [batches]);
  const all = useMemo(() => results.flatMap((r) => r.data ?? []), [results]);
  const now = Date.now() / 1000;
  const upcoming = useMemo(() => all.filter((i) => i.upcoming).sort((a, b) => a.time - b.time).slice(0, 8), [all]);
  const recent = useMemo(() => all.filter((i) => i.type !== "FOLDER" && i.time && i.time <= now && !i.upcoming).sort((a, b) => b.time - a.time).slice(0, 10), [all]); // eslint-disable-line react-hooks/exhaustive-deps
  const term = q.trim().toLowerCase();
  const found = useMemo(() => (term.length < 2 ? [] : all.filter((i) => i.title.toLowerCase().includes(term)).slice(0, 40)), [all, term]);

  if (term.length >= 2) {
    return (
      <section>
        <h2 className="mb-3 text-sm font-extrabold">Lessons, videos & PDFs matching “{q}” {loading && <span className="font-normal text-muted-foreground">· still searching…</span>}</h2>
        <div className="space-y-2">{found.map((i) => <ItemLink key={`${i.courseId}-${i.id}`} it={i} batchTitle={titles.get(i.courseId) ?? ""} />)}</div>
        {!found.length && !loading && <p className="text-sm text-muted-foreground">No lessons found.</p>}
      </section>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <section>
        <h2 className="mb-3 flex items-center gap-2 text-sm font-extrabold"><CalendarClock className="h-4 w-4 text-primary" /> Upcoming lectures</h2>
        {loading && !upcoming.length ? <Skeleton /> : upcoming.length ? (
          <div className="space-y-2">{upcoming.map((i) => <ItemLink key={`${i.courseId}-${i.id}`} it={i} batchTitle={titles.get(i.courseId) ?? ""} />)}</div>
        ) : <p className="rounded-xl bg-secondary p-4 text-sm text-muted-foreground">No scheduled lectures right now.</p>}
      </section>
      <section>
        <h2 className="mb-3 flex items-center gap-2 text-sm font-extrabold"><Sparkles className="h-4 w-4 text-primary" /> Recently added</h2>
        {loading && !recent.length ? <Skeleton /> : recent.length ? (
          <div className="space-y-2">{recent.map((i) => <ItemLink key={`${i.courseId}-${i.id}`} it={i} batchTitle={titles.get(i.courseId) ?? ""} />)}</div>
        ) : <p className="rounded-xl bg-secondary p-4 text-sm text-muted-foreground">Nothing new yet.</p>}
      </section>
    </div>
  );
}

const Skeleton = () => <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-14 animate-pulse rounded-xl bg-muted" />)}</div>;
