import { useEffect, useRef, useState } from "react";
import { Maximize, Minimize, PictureInPicture2 } from "lucide-react";
import type { VideoQuality } from "@/lib/yoapi";
import { getPosition, saveProgress } from "@/lib/progress";

const prox = (u: string) => `/api/public/stream?url=${encodeURIComponent(u)}`;

type Track = { courseId: string; videoId: string; title: string };

export function VideoPlayer({ qualities, track }: { qualities: VideoQuality[]; track?: Track }) {
  const ref = useRef<HTMLVideoElement>(null);
  const box = useRef<HTMLDivElement>(null);
  const [idx, setIdx] = useState(() => {
    const i = qualities.findIndex((q) => /720|480/.test(q.quality));
    return i >= 0 ? i : 0;
  });
  const [error, setError] = useState("");
  const [full, setFull] = useState(false);
  const first = useRef(true);

  useEffect(() => {
    const video = ref.current;
    const q = qualities[idx];
    if (!video || !q) return;
    setError("");
    let time = video.currentTime;
    if (first.current && track) { time = getPosition(track.videoId); first.current = false; }
    const src = prox(q.url);
    let hls: any;
    let cancelled = false;
    const isHls = q.url.includes(".m3u8");
    if (!isHls || video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = src;
    } else {
      import("hls.js").then(({ default: Hls }) => {
        if (cancelled) return;
        hls = new Hls();
        hls.loadSource(src);
        hls.attachMedia(video);
        hls.on(Hls.Events.ERROR, (_: unknown, d: any) => {
          if (d?.fatal) setError("This video could not be loaded. Try another quality.");
        });
      });
    }
    const onMeta = () => { if (time && time < video.duration - 5) video.currentTime = time; };
    video.addEventListener("loadedmetadata", onMeta, { once: true });
    return () => { cancelled = true; hls?.destroy(); };
  }, [idx, qualities]); // eslint-disable-line react-hooks/exhaustive-deps

  // Save where the student is, for "Continue learning".
  useEffect(() => {
    const video = ref.current;
    if (!video || !track) return;
    let last = 0;
    const save = () => {
      if (!video.currentTime) return;
      saveProgress({ ...track, position: Math.floor(video.currentTime), duration: Math.floor(video.duration || 0) });
    };
    const onTime = () => { if (Date.now() - last > 5000) { last = Date.now(); save(); } };
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("pause", save);
    return () => { save(); video.removeEventListener("timeupdate", onTime); video.removeEventListener("pause", save); };
  }, [track?.videoId]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const on = () => setFull(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", on);
    return () => document.removeEventListener("fullscreenchange", on);
  }, []);

  const toggleFull = async () => {
    const video = ref.current as any;
    try {
      if (document.fullscreenElement) { await document.exitFullscreen(); return; }
      if (box.current?.requestFullscreen) {
        await box.current.requestFullscreen();
        await (screen.orientation as any)?.lock?.("landscape").catch(() => {});
      } else if (video?.webkitEnterFullscreen) {
        video.webkitEnterFullscreen(); // iPhone
      }
    } catch { video?.webkitEnterFullscreen?.(); }
  };

  const togglePip = async () => {
    const video = ref.current as any;
    if (!video) return;
    try {
      if (document.fullscreenElement) await document.exitFullscreen().catch(() => {});
      if ((document as any).pictureInPictureElement) { await (document as any).exitPictureInPicture(); return; }
      if (video.requestPictureInPicture) await video.requestPictureInPicture();
      else if (video.webkitSetPresentationMode) {
        video.webkitSetPresentationMode(video.webkitPresentationMode === "picture-in-picture" ? "inline" : "picture-in-picture");
      } else setError("Floating window isn't supported on this browser.");
    } catch { setError("Start the video first, then tap minimize."); }
  };

  if (!qualities.length) {
    return (
      <div className="grid aspect-video place-items-center rounded-2xl bg-primary text-sm text-primary-foreground">
        Video not available yet
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div ref={box} className="relative overflow-hidden rounded-2xl bg-foreground shadow-card" onContextMenu={(e) => e.preventDefault()}>
        <video
          ref={ref}
          controls
          playsInline
          controlsList="nodownload noremoteplayback"
          onContextMenu={(e) => e.preventDefault()}
          className={full ? "h-full w-full" : "aspect-video w-full"}
        />
        <div className="absolute right-2 top-2 flex gap-2">
          <button onClick={togglePip} aria-label="Minimize (floating window)" className="grid h-9 w-9 place-items-center rounded-full bg-background/80 text-foreground backdrop-blur">
            <PictureInPicture2 className="h-4 w-4" />
          </button>
          <button onClick={toggleFull} aria-label={full ? "Exit full screen" : "Full screen"} className="grid h-9 w-9 place-items-center rounded-full bg-background/80 text-foreground backdrop-blur">
            {full ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
          </button>
        </div>
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
      {qualities.length > 1 && (
        <div className="flex flex-wrap gap-2">
          {qualities.map((q, i) => (
            <button
              key={q.url}
              onClick={() => setIdx(i)}
              className={`rounded-full px-3 py-1 text-xs font-bold transition-colors ${
                i === idx ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"
              }`}
            >
              {q.quality || `Option ${i + 1}`}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
