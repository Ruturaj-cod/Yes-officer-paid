import { Link } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { SiteHeader } from "./SiteHeader";

export function NoAccess() {
  return (
    <div className="min-h-screen">
      <SiteHeader />
      <div className="mx-auto max-w-sm px-4 py-20 text-center">
        <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-muted text-muted-foreground"><Lock className="h-6 w-6" /></span>
        <h1 className="mt-4 text-lg font-extrabold">No access</h1>
        <p className="mt-1 text-sm text-muted-foreground">This batch isn't assigned to your account. Please contact the admin.</p>
        <Link to="/home" className="mt-6 inline-block rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground">My batches</Link>
      </div>
    </div>
  );
}
