import { FileText, Loader2, X, ZoomIn, ZoomOut } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { Pdf } from "@/lib/yoapi";
import { useParams } from "@tanstack/react-router";
import { logAccess } from "@/lib/auth.functions";

const proxyUrl = (u: string, inline = false) =>
  `/api/public/pdf?url=${encodeURIComponent(u)}${inline ? "&inline=1" : ""}`;


export function PdfRow({ pdf, title }: { pdf: Pdf; title: string }) {
  const [open, setOpen] = useState(false);
  const { courseId } = useParams({ strict: false }) as { courseId?: string };
  const openPdf = () => {
    setOpen(true);
    if (courseId) logAccess({ data: { courseId, itemId: "", itemTitle: `${title} – ${pdf.title}`.slice(0, 300), kind: "pdf" } }).catch(() => {});
  };
  return (
    <>
      <div className="flex items-center gap-3 rounded-xl border border-border bg-card p-3">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-destructive/10 text-destructive">
          <FileText className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">{title}</p>
          <p className="text-xs text-muted-foreground">{pdf.title}</p>
        </div>
        <button
          onClick={openPdf}
          className="rounded-lg bg-primary px-3 py-1.5 text-xs font-bold text-primary-foreground"
        >
          Read
        </button>
      </div>
      {open && <PdfModal url={proxyUrl(pdf.url, true)} title={title} onClose={() => setOpen(false)} />}
    </>
  );
}

function PdfModal({ url, title, onClose }: { url: string; title: string; onClose: () => void }) {
  const container = useRef<HTMLDivElement>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");
  const [pages, setPages] = useState(0);
  const [zoom, setZoom] = useState(1);

  useEffect(() => {
    let cancelled = false;
    let doc: { destroy: () => Promise<void> } | null = null;
    (async () => {
      try {
        const pdfjs = await import("pdfjs-dist");
        const worker = (await import("pdfjs-dist/build/pdf.worker.min.mjs?url")).default;
        pdfjs.GlobalWorkerOptions.workerSrc = worker;
        const pdf = await pdfjs.getDocument({ url }).promise;
        doc = pdf;
        if (cancelled) return;
        setPages(pdf.numPages);
        setStatus("ready");
        const el = container.current;
        if (!el) return;
        el.innerHTML = "";
        const width = Math.min(el.clientWidth - 16, 1000) * zoom;
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        for (let i = 1; i <= pdf.numPages; i++) {
          if (cancelled) return;
          const page = await pdf.getPage(i);
          const base = page.getViewport({ scale: 1 });
          const vp = page.getViewport({ scale: (width / base.width) * dpr });
          const canvas = document.createElement("canvas");
          canvas.width = vp.width;
          canvas.height = vp.height;
          canvas.style.width = `${vp.width / dpr}px`;
          canvas.style.height = `${vp.height / dpr}px`;
          canvas.className = "mx-auto mb-3 block rounded bg-card shadow";
          el.appendChild(canvas);
          await page.render({ canvasContext: canvas.getContext("2d")!, viewport: vp }).promise;
        }
      } catch (e) {
        console.error("PDF load failed", e);
        if (!cancelled) setStatus("error");
      }
    })();
    return () => {
      cancelled = true;
      doc?.destroy();
    };
  }, [url, zoom]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-foreground/80 p-2 sm:p-6">
      <div className="flex items-center gap-2 rounded-t-xl bg-card px-4 py-2">
        <p className="min-w-0 flex-1 truncate text-sm font-bold">
          {title}
          {pages > 0 && <span className="ml-2 text-xs font-normal text-muted-foreground">{pages} pages</span>}
        </p>
        <button onClick={() => setZoom((z) => Math.max(0.6, z - 0.2))} aria-label="Zoom out" className="rounded-lg p-1 hover:bg-muted">
          <ZoomOut className="h-5 w-5" />
        </button>
        <button onClick={() => setZoom((z) => Math.min(3, z + 0.2))} aria-label="Zoom in" className="rounded-lg p-1 hover:bg-muted">
          <ZoomIn className="h-5 w-5" />
        </button>
        <button onClick={onClose} aria-label="Close" className="rounded-lg p-1 hover:bg-muted">
          <X className="h-5 w-5" />
        </button>
      </div>
      <div className="relative flex-1 select-none overflow-auto rounded-b-xl bg-muted p-2" onContextMenu={(e) => e.preventDefault()}>
        {status === "loading" && (
          <div className="absolute inset-0 grid place-items-center text-muted-foreground">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        )}
        {status === "error" && (
          <div className="grid h-full place-items-center p-6 text-center text-sm text-muted-foreground">
            This PDF couldn't be opened. Please try again later.
          </div>
        )}
        <div ref={container} />
      </div>
    </div>
  );
}
