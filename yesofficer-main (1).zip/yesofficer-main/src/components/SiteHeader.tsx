import { Link } from "@tanstack/react-router";
import { Moon, Sun, Shield } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { meQuery } from "@/lib/me";
import { useEffect, useState } from "react";

function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => {
    const d = localStorage.getItem("theme") === "dark";
    setDark(d);
    document.documentElement.classList.toggle("dark", d);
  }, []);
  const toggle = () => {
    const d = !dark;
    setDark(d);
    localStorage.setItem("theme", d ? "dark" : "light");
    document.documentElement.classList.toggle("dark", d);
  };
  return (
    <button onClick={toggle} aria-label="Toggle dark mode" className="grid h-8 w-8 place-items-center rounded-full bg-muted text-foreground">
      {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
    </button>
  );
}

export const WHATSAPP_URL = "https://whatsapp.com/channel/0029VbDWb6RF1YlYeyutve3O";

export function SiteHeader() {
  const { data: me } = useQuery({ ...meQuery, refetchInterval: false });
  const initial = (me?.displayName || me?.username || "?").charAt(0).toUpperCase();
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-card/90 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
        <Link to="/home" className="flex items-center gap-2 font-extrabold tracking-tight text-primary">
          <span className="h-8 w-8 overflow-hidden rounded-lg bg-primary">
            <img src="/logo.png" alt="YES OFFICER logo" className="h-full w-full object-cover" />
          </span>
          YES OFFICER
        </Link>
        <div className="flex items-center gap-2">
        {me?.isAdmin && (
          <Link to="/admin" aria-label="Admin panel" className="grid h-8 w-8 place-items-center rounded-full bg-muted text-foreground"><Shield className="h-4 w-4" /></Link>
        )}
        <ThemeToggle />
        <a
          href={WHATSAPP_URL}
          target="_blank"
          rel="noreferrer"
          className="bg-whatsapp rounded-full px-3 py-1.5 text-xs font-bold"
        >
          Join WhatsApp
        </a>
        <Link to="/profile" aria-label="My profile" className="grid h-8 w-8 place-items-center rounded-full bg-primary text-xs font-extrabold text-primary-foreground">{initial}</Link>
        </div>
      </div>
    </header>
  );
}

export function WhatsAppFab() {
  return (
    <a
      href={WHATSAPP_URL}
      target="_blank"
      rel="noreferrer"
      aria-label="Join our WhatsApp channel"
      className="bg-whatsapp fixed bottom-5 right-5 z-40 grid h-14 w-14 place-items-center rounded-full shadow-card transition-transform hover:scale-105"
    >
      <svg viewBox="0 0 24 24" className="h-7 w-7 fill-current" aria-hidden>
        <path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.64.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.6.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.07c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.63.71.22 1.36.19 1.87.12.57-.08 1.76-.72 2-1.41.25-.7.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35M12.05 21.5h-.01a9.4 9.4 0 0 1-4.8-1.32l-.34-.2-3.57.94.95-3.48-.22-.36a9.4 9.4 0 0 1-1.44-5.02c0-5.2 4.23-9.43 9.44-9.43a9.43 9.43 0 0 1 9.43 9.44c0 5.2-4.24 9.43-9.44 9.43m8.03-17.46A11.27 11.27 0 0 0 12.05.72C5.8.72.7 5.8.7 12.06c0 2 .52 3.95 1.52 5.67L.6 23.28l5.7-1.5a11.33 11.33 0 0 0 5.75 1.47c6.26 0 11.35-5.1 11.35-11.35 0-3.03-1.18-5.88-3.32-8.02" />
      </svg>
    </a>
  );
}
