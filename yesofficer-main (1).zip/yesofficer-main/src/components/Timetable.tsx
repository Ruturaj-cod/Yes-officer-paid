import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { CalendarDays, PlayCircle, RefreshCw } from "lucide-react";
import { fetchTimetable, type Batch } from "@/lib/yoapi";
import { timetableDateKey, timetableForBatches, type TimetableItem } from "@/lib/timetable";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

const dateLabel = (time: number) => new Date(time * 1000).toLocaleDateString("en-IN", { timeZone: "Asia/Kolkata", month: "short", day: "2-digit" });
const timeLabel = (time: number) => new Date(time * 1000).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: true });

export function Timetable({ batches }: { batches: Batch[] }) {
  const [selected, setSelected] = useState<Date>();
  const [calendarOpen, setCalendarOpen] = useState(false);
  const { data, isPending, isFetching, error, refetch } = useQuery({
    queryKey: ["timetable"], queryFn: fetchTimetable, enabled: batches.length > 0,
    staleTime: 2 * 60_000, refetchInterval: 2 * 60_000, refetchIntervalInBackground: false,
  });
  const items = useMemo(() => timetableForBatches(data ?? [], batches), [data, batches]);
  const selectedKey = selected ? `${selected.getFullYear()}-${String(selected.getMonth() + 1).padStart(2, "0")}-${String(selected.getDate()).padStart(2, "0")}` : "";
  const groups = new Map<string, TimetableItem[]>();
  for (const item of items) {
    const key = item.time ? timetableDateKey(item.time) : "live";
    if (selectedKey && key !== selectedKey) continue;
    groups.set(key, [...(groups.get(key) ?? []), item]);
  }
  if (!batches.length) return null;

  return (
    <section aria-label="Timetable" className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-2xl font-extrabold sm:text-3xl">Timetable</h2>
        <div className="flex items-center gap-2">
          <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
            <PopoverTrigger asChild><Button variant="outline"><CalendarDays />Show Calendar</Button></PopoverTrigger>
            <PopoverContent align="end" className="w-auto p-0">
              <Calendar mode="single" selected={selected} onSelect={(day) => { setSelected(day); setCalendarOpen(false); }} modifiers={{ scheduled: items.filter((item) => item.time).map((item) => new Date(`${timetableDateKey(item.time)}T12:00:00`)) }} modifiersClassNames={{ scheduled: "font-bold underline decoration-accent decoration-2 underline-offset-4" }} />
            </PopoverContent>
          </Popover>
          <Button variant="ghost" size="icon" title="Refresh timetable" aria-label="Refresh timetable" disabled={isFetching} onClick={() => void refetch()}><RefreshCw className={isFetching ? "motion-safe:animate-spin" : ""} /></Button>
        </div>
      </div>
      {selected && <div className="flex items-center gap-3 text-sm"><span className="text-muted-foreground">{selected.toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" })}</span><Button variant="link" size="sm" onClick={() => setSelected(undefined)}>All dates</Button></div>}
      {isPending && <div role="status" className="h-28 motion-safe:animate-pulse rounded-lg bg-muted"><span className="sr-only">Loading timetable</span></div>}
      {error && <div className="flex flex-wrap items-center gap-3 text-sm"><p className="text-muted-foreground">Timetable is unavailable right now.</p><Button variant="outline" size="sm" disabled={isFetching} onClick={() => void refetch()}>Retry</Button></div>}
      {!isPending && !error && groups.size === 0 && <p className="py-4 text-sm text-muted-foreground">{selected ? "No classes scheduled for this date." : "No live or upcoming classes in your batches right now."}</p>}
      {[...groups].map(([key, classes]) => (
        <div key={key} className="space-y-3">
          <div className="flex items-center gap-4"><h3 className="shrink-0 text-sm font-bold uppercase text-muted-foreground">{key === "live" ? "Live now" : dateLabel(classes[0]?.time ?? 0)}</h3><div className="h-px flex-1 bg-border" /></div>
          <div className="divide-y divide-border border-y border-border">
            {classes.map((item) => {
              const content = <><span className="grid h-12 w-16 shrink-0 place-items-center overflow-hidden rounded-md bg-secondary text-primary">{item.thumbnail ? <img src={item.thumbnail} alt="" className="h-full w-full object-cover" /> : <PlayCircle className="h-6 w-6" />}</span><span className="min-w-0 flex-1"><span className="block break-words text-sm font-bold sm:text-base">{item.title}</span><span className="mt-1 block text-xs text-muted-foreground">{item.time ? timeLabel(item.time) : "Live now"}</span><span className="mt-1 block text-xs text-muted-foreground">{item.batchTitle}</span></span><span className="col-start-2 mt-1 sm:col-auto sm:mt-0">{item.live ? <span className="inline-flex items-center gap-1.5 rounded-full bg-destructive px-3 py-1.5 text-xs font-bold text-destructive-foreground"><span className="h-1.5 w-1.5 rounded-full bg-destructive-foreground motion-safe:animate-pulse" />Live · Join</span> : <span className="text-xs font-semibold text-muted-foreground">Upcoming</span>}</span></>;
              const className = "grid grid-cols-[4rem_minmax(0,1fr)] items-center gap-x-3 gap-y-1 py-5 sm:grid-cols-[4rem_minmax(0,1fr)_auto]";
              return item.live ? <Link key={`${item.courseId}:${item.id}`} to="/batch/$courseId/video/$videoId" params={{ courseId: item.courseId, videoId: item.id }} search={{ t: item.title }} className={`${className} hover:bg-secondary/40`} aria-label={`Join live class: ${item.title}`}>{content}</Link> : <div key={`${item.courseId}:${item.id}`} className={className}>{content}</div>;
            })}
          </div>
        </div>
      ))}
    </section>
  );
}