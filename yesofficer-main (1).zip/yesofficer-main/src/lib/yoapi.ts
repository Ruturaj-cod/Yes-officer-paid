import { getApiToken, yoProxy } from "./auth.functions";
import type { TimetableItem } from "./timetable";

const API_BASE = "https://yesofficerapi.cloudflare.net.in/get";
const FALLBACK_USER_ID = "488562";

export type Batch = { id: string; title: string; thumbnail: string };
export type Pdf = { title: string; url: string };
export type Item = { id: string; title: string; type: string; thumbnail: string; pdfs: Pdf[]; fileUrl: string; time: number; upcoming: boolean; live: boolean; quizId?: string | undefined };
export type VideoQuality = { quality: string; url: string };
export type VideoDetail = { id: string; title: string; qualities: VideoQuality[]; pdfs: Pdf[]; live?: boolean };

const LIVE_WINDOW_MS = 4 * 3600_000;

/** Statuses 1/2/3 mark live-class content. Yes Officer keeps the status after a class
 *  ends, so a class only counts as live within a few hours of its start time. */
export function liveState(type: string, x: any, now = Date.now()): { upcoming: boolean; live: boolean } {
  const status = Number(x?.live_status);
  const start = Number(x?.strtotime) * 1000;
  if (type !== "VIDEO" || !(status === 1 || status === 2 || status === 3) || !start) return { upcoming: false, live: false };
  if (start > now) return status === 3 ? { upcoming: false, live: true } : { upcoming: true, live: false };
  return { upcoming: false, live: now - start < LIVE_WINDOW_MS };
}

/** Reads the Yes Officer account id from the token so any saved token works. */
export function userIdFromToken(t: string): string {
  try {
    const part = t.split(".")[1] ?? "";
    const json = JSON.parse(atob(part.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(part.length / 4) * 4, "=")));
    const id = String(json?.id ?? "").trim();
    return /^\d+$/.test(id) ? id : FALLBACK_USER_ID;
  } catch {
    return FALLBACK_USER_ID;
  }
}

let tokenPromise: Promise<string> | null = null;
const token = () => (tokenPromise ??= getApiToken().catch((e) => { tokenPromise = null; throw e; }));
const userId = async () => userIdFromToken(await token());

let keyPromise: Promise<CryptoKey> | null = null;
const aesKey = () =>
  (keyPromise ??= crypto.subtle.importKey("raw", new TextEncoder().encode("638udh3829162018"), { name: "AES-CBC" }, false, ["decrypt"]));

const b64 = (s: string) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

async function decryptLink(value: unknown): Promise<string> {
  if (typeof value !== "string" || !value) return "";
  if (value.startsWith("http")) return value;
  if (!value.includes(":")) return "";
  try {
    const [c = "", iv = ""] = value.split(":");
    const out = await crypto.subtle.decrypt({ name: "AES-CBC", iv: b64(iv) }, await aesKey(), b64(c));
    return new TextDecoder().decode(out);
  } catch {
    return "";
  }
}

// Yes Officer rate-limits the shared token (429 with no CORS headers, which the
// browser reports as "Failed to fetch"), so keep requests few and serialized.
const MAX_IN_FLIGHT = 2;
let inFlight = 0;
const waiters: (() => void)[] = [];
async function acquire() {
  if (inFlight < MAX_IN_FLIGHT) { inFlight++; return; }
  await new Promise<void>((r) => waiters.push(r));
  inFlight++;
}
function release() { inFlight--; waiters.shift()?.(); }
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// Set once the browser can't reach Yes Officer directly (other hosts); later calls go via our server.
let viaServer = false;
async function proxyGet(path: string): Promise<Response | null> {
  try {
    const r = await yoProxy({ data: { path } });
    return new Response(r.status === 200 ? r.body : null, { status: r.status });
  } catch {
    return null;
  }
}

async function apiGet(path: string): Promise<any> {
  const auth = await token();
  for (let attempt = 0; ; attempt++) {
    if (viaServer) {
      const res = await proxyGet(path);
      if (res && res.ok) return res.json();
      if (res && (res.status === 401 || res.status === 403)) throw new Error("Access expired — the token needs updating.");
      if (attempt >= 3) throw new Error(res ? `Could not load content (${res.status})` : "The content server is busy right now. Please wait a minute and tap Retry.");
      await sleep(1500 * 2 ** attempt);
      continue;
    }
    await acquire();
    let res: Response | null = null;
    try {
      res = await fetch(`${API_BASE}/${path}`, {
        headers: { Authorization: auth, "Auth-Key": "appxapi", "client-service": "Appx", source: "website", "User-ID": userIdFromToken(auth) },
      });
    } catch {
      res = null; // network error or rate-limit response without CORS headers
    } finally {
      release();
    }
    if (!res && attempt === 0) {
      // Direct call blocked: try through our server once; keep using it if it works.
      const alt = await proxyGet(path);
      if (alt && alt.ok) { viaServer = true; return alt.json(); }
    }
    if (res && res.ok) return res.json();
    if (res && (res.status === 401 || res.status === 403)) throw new Error("Access expired — the token needs updating.");
    if (attempt >= 3) {
      throw new Error(res ? `Could not load content (${res.status})` : "The content server is busy right now. Please wait a minute and tap Retry.");
    }
    await sleep(1500 * 2 ** attempt);
  }
}

async function collectPdfs(x: any): Promise<Pdf[]> {
  const out: Pdf[] = [];
  const seen = new Set<string>();
  for (const [v, label] of [[x.pdf_link, "Notes"], [x.pdf_link2, "Notes 2"], [x.study_material_link, "Study material"]] as const) {
    const url = await decryptLink(v);
    const base = url.split("?")[0] ?? "";
    if (url && !seen.has(base)) { seen.add(base); out.push({ title: label, url }); }
  }
  return out;
}

export async function fetchBatches(): Promise<Batch[]> {
  const json = await apiGet(`mycoursev2?userid=${await userId()}`);
  const list: any[] = Array.isArray(json?.data) ? json.data : [];
  return list.map((c) => ({ id: String(c.id), title: String(c.course_name ?? `Batch ${c.id}`).trim(), thumbnail: c.course_thumbnail ?? "" }));
}

export async function fetchFolder(courseId: string, parentId: string): Promise<Item[]> {
  const items: Item[] = [];
  for (let start = 0; start < 10; start++) {
    const json = await apiGet(`folder_contentsv3?course_id=${encodeURIComponent(courseId)}&parent_id=${encodeURIComponent(parentId)}&start=${start}`);
    const list: any[] = Array.isArray(json?.data) ? json.data : [];
    const before = items.length;
    for (const x of list) {
      if (items.some((i) => i.id === String(x.id))) continue;
      const type = String(x.material_type ?? "FILE");
      items.push({
        id: String(x.id),
        title: String(x.Title ?? "Untitled"),
        type,
        quizId: type === "TEST" ? String(x.quiz_title_id ?? x.quiz_id ?? "") : undefined,
        thumbnail: x.thumbnail ?? "",
        pdfs: type === "VIDEO" || type === "FOLDER" ? [] : await collectPdfs(x),
        fileUrl: type === "IMAGE" ? await decryptLink(x.file_link) : "",
        time: Number(x.strtotime) || 0,
        ...liveState(type, x),
      });
    }
    if (list.length < 20 || items.length === before) break;
  }
  return items;
}

export async function fetchVideo(courseId: string, videoId: string): Promise<VideoDetail> {
  const json = await apiGet(`fetchVideoDetailsById?course_id=${encodeURIComponent(courseId)}&video_id=${encodeURIComponent(videoId)}&ytflag=0&folder_wise_course=1`);
  const d = json?.data;
  if (!d || typeof d !== "object") throw new Error(json?.message ?? "Video not found");
  const qualities: VideoQuality[] = [];
  const seen = new Set<string>();
  const push = (quality: string, url: string) => { if (url && !seen.has(url)) { seen.add(url); qualities.push({ quality, url }); } };
  for (const l of d.download_links ?? []) push(String(l.quality ?? ""), await decryptLink(l.path));
  for (const l of d.encrypted_links ?? []) push(String(l.quality ?? ""), await decryptLink(l.path));
  const live = !qualities.length;
  if (live) {
    for (const l of d.livestream_links ?? []) push(String(l.quality ?? ""), await decryptLink(l.path));
    push("Auto", await decryptLink(d.file_link));
  }
  return { id: String(d.id), title: String(d.Title ?? ""), qualities, pdfs: await collectPdfs(d), live };
}

export type IndexedItem = Item & { courseId: string; parentId: string; path: { id: string; t: string }[] };

/** One timetable request covers all purchased batches, rather than polling each batch. */
export async function fetchTimetable(): Promise<TimetableItem[]> {
  const json = await apiGet(`purchasedlivecourseclassbytypev2?userid=${await userId()}&start=-1&include_free_classes=0`);
  const list: any[] = Array.isArray(json?.data) ? json.data : [];
  return list.flatMap((x) => {
    const id = String(x?.id ?? "");
    const courseId = String(x?.course_id ?? x?.courseid ?? "");
    if (!id || !courseId) return [];
    const type = String(x?.material_type ?? "VIDEO").toUpperCase();
    const state = liveState(type, x);
    if (!state.live && !state.upcoming) return [];
    return [{ id, courseId, batchTitle: String(x?.course_name ?? ""), title: String(x?.Title ?? x?.title ?? "Live class"), type, thumbnail: String(x?.thumbnail ?? x?.course_thumbnail ?? ""), pdfs: [], fileUrl: "", time: Number(x?.strtotime) || 0, ...state }];
  });
}

/** Live & scheduled classes for a batch, from Yes Officer's dedicated timetable list
 *  (live classes only move into the normal folder hours after they end). */
export async function fetchLiveClasses(courseId: string): Promise<Item[]> {
  const out: Item[] = [];
  const seen = new Set<string>();
  for (const status of [1, 2]) {
    try {
      const json = await apiGet(`course_contents_by_live_status?course_id=${encodeURIComponent(courseId)}&live_status=${status}&start=0`);
      const list: any[] = Array.isArray(json?.data) ? json.data : [];
      for (const x of list) {
        const id = String(x?.id ?? "");
        if (!id || seen.has(id)) continue;
        seen.add(id);
        const type = String(x?.material_type ?? "VIDEO");
        if (type !== "VIDEO") continue;
        out.push({
          id,
          title: String(x?.Title ?? x?.title ?? "Live class"),
          type,
          thumbnail: x?.thumbnail ?? "",
          pdfs: [],
          fileUrl: "",
          time: Number(x?.strtotime) || 0,
          ...liveState(type, x),
        });
      }
    } catch {
      // live list unavailable for this batch — folder view still works
    }
  }
  return out.filter((i) => i.live || i.upcoming).sort((a, b) => a.time - b.time);
}

/** Walks every folder of a batch (browser-side) so we can search and list upcoming/recent content. */
export async function fetchBatchIndex(courseId: string): Promise<IndexedItem[]> {
  const out: IndexedItem[] = [];
  const queue: { id: string; path: { id: string; t: string }[] }[] = [{ id: "-1", path: [] }];
  let visited = 0;
  while (queue.length && visited < 250) {
    const batch = queue.splice(0, 5);
    visited += batch.length;
    const results = await Promise.all(batch.map((f) => fetchFolder(courseId, f.id).then((items) => ({ f, items })).catch(() => ({ f, items: [] as Item[] }))));
    for (const { f, items } of results) {
      for (const it of items) {
        out.push({ ...it, courseId, parentId: f.id, path: f.path });
        if (it.type === "FOLDER") queue.push({ id: it.id, path: [...f.path, { id: it.id, t: it.title }] });
      }
    }
  }
  return out;
}

const FOLDER_FRESH_MS = 30 * 60_000;

/** Folder lists are saved in the shared cache: recent copies skip Yes Officer, and any saved copy
 *  is used when Yes Officer fails (expired token, 429), so cached lectures and notes stay reachable. */
export async function fetchFolderCached(courseId: string, parentId: string, fresh = false): Promise<Item[]> {
  const { supabase } = await import("@/integrations/supabase/client");
  const { data: row } = await supabase.from("cached_content").select("data, updated_at").eq("course_id", courseId).eq("item_id", parentId).eq("kind", "FOLDER").maybeSingle();
  const saved = Array.isArray((row?.data as any)?.items) ? ((row!.data as any).items as Item[]) : null;
  const age = row ? Date.now() - new Date(row.updated_at).getTime() : Infinity;
  if (!fresh && saved && age < FOLDER_FRESH_MS) return saved.map((i) => ({ ...i, live: false }));
  try {
    const items = await fetchFolder(courseId, parentId);
    if (items.length) {
      await supabase.from("cached_content").upsert({ course_id: courseId, item_id: parentId, kind: "FOLDER", title: "", data: { items } as any, updated_at: new Date().toISOString() });
    }
    return items;
  } catch (e) {
    if (saved) return saved.map((i) => ({ ...i, live: false }));
    throw e;
  }
}


export type TestQuestion = { id: string; html: string; options: string[]; answer: number };
export type TestDetail = { id: string; title: string; minutes: number; totalMarks: number; questions: TestQuestion[] };

/** Parses a Yes Officer test payload into our quiz shape. Tolerant of field-name variants. */
export function parseTest(id: string, d: any): TestDetail {
  const rawQs: any[] = Array.isArray(d?.questions) ? d.questions : Array.isArray(d?.question_list) ? d.question_list : [];
  const questions: TestQuestion[] = rawQs.map((q, i) => {
    const opts: string[] = Array.isArray(q?.options)
      ? q.options.map((o: any) => String(typeof o === "object" ? (o?.option ?? o?.title ?? o?.text ?? "") : o))
      : [q?.option_1, q?.option_2, q?.option_3, q?.option_4, q?.option_5].filter((o) => o != null && o !== "").map(String);
    let answer = Number(q?.correct_option ?? q?.answer ?? q?.correct_answer ?? 0);
    if (!(answer >= 1 && answer <= opts.length)) answer = 0; // 0 = unknown
    return {
      id: String(q?.id ?? q?.question_id ?? i + 1),
      html: String(q?.question ?? q?.question_title ?? q?.title ?? ""),
      options: opts,
      answer,
    };
  }).filter((q) => q.html || q.options.length);
  return {
    id,
    title: String(d?.title ?? d?.test_title ?? d?.quiz_title ?? "Test"),
    minutes: Number(d?.time_in_mins ?? d?.duration ?? d?.total_time ?? 0) || 0,
    totalMarks: Number(d?.total_marks ?? d?.marks ?? 0) || 0,
    questions,
  };
}

export async function fetchTest(testId: string): Promise<TestDetail> {
  const json = await apiGet(`test_title_by_id?id=${encodeURIComponent(testId)}`);
  const d = json?.data;
  if (!d || typeof d !== "object") throw new Error(json?.message ?? "Test not found");
  let t = parseTest(testId, d);
  // Yes Officer returns only metadata here (questions is a count); the real question
  // list lives in a separate JSON file linked from the payload.
  if (!t.questions.length) {
    const qUrl = String(
      d?.test_questions_url ?? d?.questions_url ?? d?.question_url ?? d?.questions_file ?? d?.file_url ?? "",
    );
    if (qUrl && /^https?:\/\//i.test(qUrl)) {
      const res = await fetch(qUrl);
      if (!res.ok) throw new Error("Could not load the questions file.");
      const qJson = await res.json().catch(() => null);
      const qData = qJson?.data ?? qJson;
      if (qData && typeof qData === "object") {
        const merged = parseTest(testId, { ...d, ...qData, questions: qData.questions ?? qData.question_list });
        if (merged.questions.length) t = merged;
      }
    }
  }
  if (!t.questions.length) throw new Error("This test has no questions yet.");
  return t;
}

/** Shared cache: a test fetched once is saved for every student, so Yes Officer is hit only the first time. */
export async function fetchTestCached(courseId: string, testId: string, fresh = false): Promise<TestDetail> {
  const { supabase } = await import("@/integrations/supabase/client");
  if (!fresh) {
    const { data } = await supabase.from("cached_content").select("data").eq("course_id", courseId).eq("item_id", testId).eq("kind", "TEST").maybeSingle();
    const d = data?.data as TestDetail | undefined;
    if (d && Array.isArray(d.questions) && d.questions.length) return d;
  }
  const t = await fetchTest(testId);
  await supabase.from("cached_content").upsert({ course_id: courseId, item_id: testId, kind: "TEST", title: t.title, data: t as any, updated_at: new Date().toISOString() });
  return t;
}

/** Shared cache: a lecture fetched once is saved for every student, so Yes Officer is hit only the first time. */
export async function fetchVideoCached(courseId: string, videoId: string, fresh = false): Promise<VideoDetail> {
  const { supabase } = await import("@/integrations/supabase/client");
  if (!fresh) {
    const { data } = await supabase.from("cached_content").select("data").eq("course_id", courseId).eq("item_id", videoId).eq("kind", "VIDEO").maybeSingle();
    const d = data?.data as VideoDetail | undefined;
    if (d && !d.live && Array.isArray(d.qualities) && d.qualities.length) return d;
  }
  const v = await fetchVideo(courseId, videoId);
  if (v.qualities.length && !v.live) {
    await supabase.from("cached_content").upsert({ course_id: courseId, item_id: videoId, kind: "VIDEO", title: v.title, data: v as any, updated_at: new Date().toISOString() });
  }
  return v;
}
