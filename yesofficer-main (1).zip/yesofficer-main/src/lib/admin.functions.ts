import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { requireActive } from "./guard.server";
import { USERNAME_RE, normalizeUsername, usernameToEmail } from "./access";

async function admin(ctx: { supabase: any; userId: string; claims: unknown }) {
  const me = await requireActive(ctx.supabase, ctx.userId, ctx.claims);
  if (!me.isAdmin) throw new Error("Owner only");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export const listUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const db = await admin(context);
    const [{ data: profiles }, { data: access }, { data: roles }, { data: devices }] = await Promise.all([
      db.from("profiles").select("id, username, display_name, suspended, created_at").order("created_at", { ascending: false }),
      db.from("batch_access").select("user_id, course_id"),
      db.from("user_roles").select("user_id, role"),
      db.from("login_devices").select("user_id, device, ip, created_at").order("created_at", { ascending: false }).limit(1000),
    ]);
    return (profiles ?? []).map((p) => ({
      id: p.id, username: p.username, displayName: p.display_name, suspended: p.suspended, createdAt: p.created_at,
      isAdmin: !!roles?.some((r) => r.user_id === p.id && r.role === "admin"),
      courseIds: (access ?? []).filter((a) => a.user_id === p.id).map((a) => a.course_id),
      lastDevice: devices?.find((d) => d.user_id === p.id) ?? null,
    }));
  });

export const createUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ username: z.string(), password: z.string().min(6).max(72), name: z.string().max(80) }).parse(d))
  .handler(async ({ data, context }) => {
    const db = await admin(context);
    const username = normalizeUsername(data.username);
    if (!USERNAME_RE.test(username)) throw new Error("Username: 3–32 letters, numbers, . _ -");
    const { data: exists } = await db.from("profiles").select("id").eq("username", username).maybeSingle();
    if (exists) throw new Error("Username already taken");
    const { data: created, error } = await db.auth.admin.createUser({ email: usernameToEmail(username), password: data.password, email_confirm: true });
    if (error || !created.user) throw new Error(error?.message ?? "Could not create user");
    const { error: e2 } = await db.from("profiles").insert({ id: created.user.id, username, display_name: data.name || username });
    if (e2) throw new Error(e2.message);
    await db.from("user_roles").insert({ user_id: created.user.id, role: "user" });
    return { id: created.user.id };
  });

export const resetPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ userId: z.string().uuid(), password: z.string().min(6).max(72) }).parse(d))
  .handler(async ({ data, context }) => {
    const db = await admin(context);
    const { error } = await db.auth.admin.updateUserById(data.userId, { password: data.password });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const setSuspended = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ userId: z.string().uuid(), suspended: z.boolean() }).parse(d))
  .handler(async ({ data, context }) => {
    if (data.userId === context.userId) throw new Error("You can't suspend yourself");
    const db = await admin(context);
    await db.from("profiles").update({ suspended: data.suspended }).eq("id", data.userId);
    return { ok: true };
  });

export const setAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ userId: z.string().uuid(), admin: z.boolean() }).parse(d))
  .handler(async ({ data, context }) => {
    if (data.userId === context.userId) throw new Error("You can't change your own role");
    const db = await admin(context);
    if (data.admin) {
      const { data: has } = await db.from("user_roles").select("id").eq("user_id", data.userId).eq("role", "admin").maybeSingle();
      if (!has) await db.from("user_roles").insert({ user_id: data.userId, role: "admin" });
    } else {
      await db.from("user_roles").delete().eq("user_id", data.userId).eq("role", "admin");
    }
    return { ok: true };
  });


export const setBatchAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ userId: z.string().uuid(), courseId: z.string().max(40), grant: z.boolean() }).parse(d))
  .handler(async ({ data, context }) => {
    const db = await admin(context);
    if (data.grant) await db.from("batch_access").upsert({ user_id: data.userId, course_id: data.courseId });
    else await db.from("batch_access").delete().eq("user_id", data.userId).eq("course_id", data.courseId);
    return { ok: true };
  });

export const setAllBatchAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ userId: z.string().uuid(), courseIds: z.array(z.string().max(40)).max(500), grant: z.boolean() }).parse(d))
  .handler(async ({ data, context }) => {
    const db = await admin(context);
    if (data.grant) {
      if (data.courseIds.length) {
        const { error } = await db.from("batch_access").upsert(data.courseIds.map((course_id) => ({ user_id: data.userId, course_id })));
        if (error) throw new Error(error.message);
      }
    } else {
      await db.from("batch_access").delete().eq("user_id", data.userId);
    }
    return { ok: true };
  });

export const searchLogs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ q: z.string().max(100).default(""), userId: z.string().default(""), from: z.string().default(""), to: z.string().default("") }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const db = await admin(context);
    let query = db.from("access_logs").select("id, username, course_id, item_title, kind, created_at").order("created_at", { ascending: false }).limit(300);
    if (data.userId) query = query.eq("user_id", data.userId);
    if (data.from) query = query.gte("created_at", data.from);
    if (data.to) query = query.lte("created_at", `${data.to}T23:59:59.999Z`);
    const q = data.q.replace(/[,()%*]/g, " ").trim();
    if (q) query = query.or(`username.ilike.%${q}%,item_title.ilike.%${q}%,course_id.ilike.%${q}%,kind.ilike.%${q}%`);
    const { data: rows, error } = await query;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const listDevices = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ userId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const db = await admin(context);
    const { data: rows } = await db.from("login_devices").select("id, device, user_agent, ip, created_at").eq("user_id", data.userId).order("created_at", { ascending: false }).limit(30);
    return rows ?? [];
  });
