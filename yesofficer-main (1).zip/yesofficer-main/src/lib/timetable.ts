import type { Batch, Item } from "./yoapi";

export type TimetableItem = Item & { courseId: string; batchTitle: string };

export function timetableDateKey(seconds: number): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(seconds * 1000));
}

/** Never infer access from a class title; match its explicit course identifier. */
export function timetableForBatches(items: TimetableItem[], batches: Batch[]): TimetableItem[] {
  const allowed = new Map(batches.map((batch) => [batch.id, batch]));
  const seen = new Set<string>();
  return items.filter((item) => {
    const key = `${item.courseId}:${item.id}`;
    if (!allowed.has(item.courseId) || seen.has(key) || (!item.live && !item.upcoming)) return false;
    seen.add(key);
    return true;
  }).map((item) => ({ ...item, batchTitle: allowed.get(item.courseId)?.title ?? item.batchTitle, thumbnail: item.thumbnail || allowed.get(item.courseId)?.thumbnail || "" }))
    .sort((a, b) => a.time - b.time);
}