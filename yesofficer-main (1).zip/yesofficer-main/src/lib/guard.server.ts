import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { deviceStatus } from "./access";

export async function loadMe(supabase: SupabaseClient<Database>, userId: string, claims: unknown) {
  const sessionId = (claims as { session_id?: string })?.session_id;
  const [{ data: profile }, { data: roles }, { data: access }] = await Promise.all([
    supabase.from("profiles").select("username, display_name, suspended, active_session_id, avatar_url").eq("id", userId).maybeSingle(),
    supabase.from("user_roles").select("role").eq("user_id", userId),
    supabase.from("batch_access").select("course_id").eq("user_id", userId),
  ]);
  return {
    status: deviceStatus(profile, sessionId),
    sessionId,
    username: profile?.username ?? "",
    displayName: profile?.display_name ?? "",
    avatarUrl: profile?.avatar_url ?? "",
    isAdmin: !!roles?.some((r) => r.role === "admin"),
    courseIds: (access ?? []).map((a) => a.course_id),
  };
}

export async function requireActive(supabase: SupabaseClient<Database>, userId: string, claims: unknown) {
  const me = await loadMe(supabase, userId, claims);
  if (me.status !== "ok") throw new Error(`ACCESS_${me.status.toUpperCase()}`);
  return me;
}
