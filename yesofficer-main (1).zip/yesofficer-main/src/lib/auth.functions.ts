import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { loadMe, requireActive } from "./guard.server";
import { USERNAME_RE, deviceLabel, normalizeUsername, usernameToEmail } from "./access";

export const hasOwner = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { count } = await supabaseAdmin.from("user_roles").select("id", { count: "exact", head: true }).eq("role", "admin");
  return (count ?? 0) > 0;
});

// One-time: creates the first owner account. Disabled once any admin exists.
export const setupOwner = createServerFn({ method: "POST" })
  .inputValidator((d) =>
    z.object({ username: z.string(), password: z.string().min(6).max(72), name: z.string().max(80) }).parse(d),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { count } = await supabaseAdmin.from("user_roles").select("id", { count: "exact", head: true }).eq("role", "admin");
    if ((count ?? 0) > 0) throw new Error("Owner already exists");
    const username = normalizeUsername(data.username);
    if (!USERNAME_RE.test(username)) throw new Error("Username: 3–32 letters, numbers, . _ -");
    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email: usernameToEmail(username),
      password: data.password,
      email_confirm: true,
    });
    if (error || !created.user) throw new Error(error?.message ?? "Could not create owner");
    await supabaseAdmin.from("profiles").insert({ id: created.user.id, username, display_name: data.name || username });
    await supabaseAdmin.from("user_roles").insert({ user_id: created.user.id, role: "admin" });
    return { ok: true };
  });

// Called right after sign-in: makes this device the only active one.
export const claimDevice = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const me = await loadMe(context.supabase, context.userId, context.claims);
    if (me.status === "missing") throw new Error("Account not set up");
    if (me.status === "suspended") throw new Error("ACCESS_SUSPENDED");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("profiles").update({ active_session_id: me.sessionId ?? null }).eq("id", context.userId);
    await supabaseAdmin.from("access_logs").insert({ user_id: context.userId, username: me.username, kind: "login", item_title: "Signed in" });
    const ua = (getRequestHeader("user-agent") ?? "").slice(0, 400);
    const ip = (getRequestHeader("cf-connecting-ip") ?? getRequestHeader("x-forwarded-for") ?? "").split(",")[0]!.trim().slice(0, 60);
    await supabaseAdmin.from("login_devices").insert({ user_id: context.userId, username: me.username, device: deviceLabel(ua), user_agent: ua, ip });
    return { ok: true };
  });

export const getMe = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const me = await loadMe(context.supabase, context.userId, context.claims);
    return { status: me.status, username: me.username, displayName: me.displayName, avatarUrl: me.avatarUrl, isAdmin: me.isAdmin, courseIds: me.courseIds };
  });

// Yes Officer blocks our server host, so the browser calls their API directly.
// The token is only handed to active users on their current device.
export const getApiToken = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await requireActive(context.supabase, context.userId, context.claims);
    const t = process.env["YESOFFICER_TOKEN"];
    if (!t) throw new Error("Content token is missing");
    return t;
  });

// Fallback for hosts where the browser can't reach Yes Officer directly (e.g. other
// domains blocked by their CORS/firewall): the server makes the same request.
const YO_PATHS = ["mycoursev2?", "folder_contentsv3?", "fetchVideoDetailsById?", "purchasedlivecourseclassbytypev2?", "course_contents_by_live_status?", "test_title_by_id?"];
export const yoProxy = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ path: z.string().max(400) }).parse(d))
  .handler(async ({ data, context }) => {
    await requireActive(context.supabase, context.userId, context.claims);
    if (!YO_PATHS.some((p) => data.path.startsWith(p))) throw new Error("Not allowed");
    const t = process.env["YESOFFICER_TOKEN"];
    if (!t) throw new Error("Content token is missing");
    const { userIdFromToken } = await import("./yoapi");
    const res = await fetch(`https://yesofficerapi.cloudflare.net.in/get/${data.path}`, {
      headers: { Authorization: t, "Auth-Key": "appxapi", "client-service": "Appx", source: "website", "User-ID": userIdFromToken(t) },
    });
    return { status: res.status, body: res.ok ? await res.text() : "" };
  });


export const logAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({
      courseId: z.string().max(40),
      itemId: z.string().max(40).default(""),
      itemTitle: z.string().max(300).default(""),
      kind: z.enum(["batch", "folder", "video", "pdf", "test"]),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const me = await requireActive(context.supabase, context.userId, context.claims);
    if (!me.isAdmin && !me.courseIds.includes(data.courseId)) throw new Error("No access to this batch");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("access_logs").insert({
      user_id: context.userId, username: me.username, course_id: data.courseId,
      item_id: data.itemId, item_title: data.itemTitle, kind: data.kind,
    });
    return { ok: true };
  });

export const setAvatar = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ path: z.string().max(200) }).parse(d))
  .handler(async ({ data, context }) => {
    await requireActive(context.supabase, context.userId, context.claims);
    if (data.path && !data.path.startsWith(`${context.userId}/`)) throw new Error("Invalid file");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("profiles").update({ avatar_url: data.path }).eq("id", context.userId);
    return { ok: true };
  });
