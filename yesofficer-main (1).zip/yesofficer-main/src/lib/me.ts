import { queryOptions, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getMe, logAccess } from "./auth.functions";

export const meQuery = queryOptions({
  queryKey: ["me"],
  queryFn: () => getMe(),
  staleTime: 15_000,
  refetchInterval: 30_000,
  refetchOnWindowFocus: true,
});

export async function signOutTo(reason?: "replaced" | "suspended") {
  await supabase.auth.signOut();
  window.location.replace(reason ? `/auth?reason=${reason}` : "/auth");
}

/** Watches the account; signs out when another device takes over or the account is suspended. */
export function useMe() {
  const q = useQuery(meQuery);
  const status = q.data?.status;
  useEffect(() => {
    if (status === "replaced" || status === "suspended") void signOutTo(status);
    else if (status === "missing") void signOutTo();
  }, [status]);
  return q;
}

export function useSignOut() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  return async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };
}

export function useLogAccess(entry: { courseId: string; itemId?: string; itemTitle?: string; kind: "batch" | "folder" | "video" | "pdf" | "test" } | null) {
  const key = entry ? `${entry.kind}:${entry.courseId}:${entry.itemId ?? ""}` : "";
  useEffect(() => {
    if (!entry) return;
    logAccess({ data: { courseId: entry.courseId, itemId: entry.itemId ?? "", itemTitle: entry.itemTitle ?? "", kind: entry.kind } }).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
}
