// Pure access rules shared by server and browser.

export const USERNAME_RE = /^[a-z0-9._-]{3,32}$/;

export function normalizeUsername(u: string) {
  return u.trim().toLowerCase();
}

export function usernameToEmail(u: string) {
  return `${normalizeUsername(u)}@users.yesofficer.local`;
}

export type DeviceStatus = "ok" | "replaced" | "suspended" | "missing";

export function deviceStatus(
  profile: { suspended: boolean; active_session_id: string | null } | null | undefined,
  sessionId: string | undefined,
): DeviceStatus {
  if (!profile) return "missing";
  if (profile.suspended) return "suspended";
  if (profile.active_session_id && profile.active_session_id !== sessionId) return "replaced";
  return "ok";
}

export function visibleBatches<T extends { id: string }>(batches: T[], allowed: string[], isAdmin: boolean): T[] {
  if (isAdmin) return batches;
  const set = new Set(allowed);
  return batches.filter((b) => set.has(b.id));
}

export function canOpenBatch(courseId: string, allowed: string[], isAdmin: boolean) {
  return isAdmin || allowed.includes(courseId);
}

export type ChatRules = {
  banned: boolean; block_text: boolean; block_emoji: boolean;
  block_image: boolean; block_video: boolean; block_audio: boolean;
};
export type MediaType = "" | "image" | "video" | "audio";

const EMOJI_RE = /\p{Extended_Pictographic}/u;
export const hasEmoji = (s: string) => EMOJI_RE.test(s);

/** Returns why a chat message is not allowed, or "" when it can be sent. Owner is never restricted. */
export function chatBlockReason(rules: ChatRules | null | undefined, msg: { body: string; mediaType: MediaType }, isAdmin = false): string {
  if (isAdmin || !rules) return "";
  if (rules.banned) return "You are banned from the chat.";
  const body = msg.body.trim();
  if (body && rules.block_emoji && hasEmoji(body)) return "You can't send emoji or stickers.";
  if (body && rules.block_text && body.replace(/\p{Extended_Pictographic}|\s|\uFE0F|\u200D/gu, "")) return "You can't send text messages.";
  if (msg.mediaType === "image" && rules.block_image) return "You can't send photos or stickers.";
  if (msg.mediaType === "video" && rules.block_video) return "You can't send videos.";
  if (msg.mediaType === "audio" && rules.block_audio) return "You can't send audio or songs.";
  return "";
}

export function deviceLabel(ua: string): string {
  const os = /Android ([\d.]+)/.exec(ua)?.[0] ?? (/iPhone|iPad/.test(ua) ? (/iPad/.test(ua) ? "iPad" : "iPhone") : /Windows/.test(ua) ? "Windows" : /Mac OS X/.test(ua) ? "Mac" : /Linux/.test(ua) ? "Linux" : "Unknown device");
  const model = /Android[^;]*;\s*([^;)]+?)(?:\sBuild|\))/.exec(ua)?.[1]?.trim();
  const browser = /Edg\//.test(ua) ? "Edge" : /SamsungBrowser/.test(ua) ? "Samsung Internet" : /CriOS|Chrome\//.test(ua) ? "Chrome" : /FxiOS|Firefox\//.test(ua) ? "Firefox" : /Safari\//.test(ua) ? "Safari" : "Browser";
  return [model && model !== "K" ? model : "", os, browser].filter(Boolean).join(" · ");
}
