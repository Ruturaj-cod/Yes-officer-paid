import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export async function uploadFile(bucket: "avatars" | "chat", userId: string, file: File) {
  const ext = (file.name.split(".").pop() || "bin").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 8);
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, { contentType: file.type, upsert: false });
  if (error) throw new Error("Upload failed. Max size: avatars 5 MB, chat 50 MB.");
  return path;
}

export function useFileUrl(bucket: "avatars" | "chat", path: string | null | undefined) {
  const { data } = useQuery({
    queryKey: ["file", bucket, path],
    enabled: !!path,
    staleTime: 50 * 60_000,
    queryFn: async () => {
      const { data } = await supabase.storage.from(bucket).createSignedUrl(path!, 3600);
      return data?.signedUrl ?? "";
    },
  });
  return data ?? "";
}

export function Avatar({ path, name, className = "h-8 w-8 text-xs" }: { path?: string | null; name: string; className?: string }) {
  const url = useFileUrl("avatars", path);
  return url ? (
    <img src={url} alt={name} className={`shrink-0 rounded-full object-cover ${className}`} />
  ) : (
    <span className={`grid shrink-0 place-items-center rounded-full bg-primary font-extrabold text-primary-foreground ${className}`}>{(name || "?").charAt(0).toUpperCase()}</span>
  );
}
