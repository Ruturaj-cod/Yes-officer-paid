import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { requireActive } from "./guard.server";
import { chatBlockReason } from "./access";

export const getMyChatRules = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.from("chat_restrictions").select("*").eq("user_id", context.userId).maybeSingle();
    return data;
  });

export const sendMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ body: z.string().max(2000), mediaPath: z.string().max(300).default(""), mediaType: z.enum(["", "image", "video", "audio"]).default("") }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const me = await requireActive(context.supabase, context.userId, context.claims);
    if (!data.body.trim() && !data.mediaPath) throw new Error("Message is empty");
    if (data.mediaPath && !data.mediaPath.startsWith(`${context.userId}/`)) throw new Error("Invalid file");
    if (!!data.mediaPath !== !!data.mediaType) throw new Error("Invalid file");
    const { data: rules } = await context.supabase.from("chat_restrictions").select("*").eq("user_id", context.userId).maybeSingle();
    const reason = chatBlockReason(rules, { body: data.body, mediaType: data.mediaType }, me.isAdmin);
    if (reason) throw new Error(reason);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("chat_messages").insert({
      user_id: context.userId, username: me.username, display_name: me.displayName, avatar_url: me.avatarUrl,
      is_admin: me.isAdmin, body: data.body.trim(), media_url: data.mediaPath, media_type: data.mediaType,
    });
    if (error) throw new Error("Could not send message");
    return { ok: true };
  });

async function owner(ctx: { supabase: any; userId: string; claims: unknown }) {
  const me = await requireActive(ctx.supabase, ctx.userId, ctx.claims);
  if (!me.isAdmin) throw new Error("Owner only");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export const deleteMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const db = await owner(context);
    await db.from("chat_messages").delete().eq("id", data.id);
    return { ok: true };
  });

const rulesSchema = z.object({
  userId: z.string().uuid(), banned: z.boolean(), block_text: z.boolean(), block_emoji: z.boolean(),
  block_image: z.boolean(), block_video: z.boolean(), block_audio: z.boolean(),
});

export const getChatRules = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ userId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const db = await owner(context);
    const { data: r } = await db.from("chat_restrictions").select("*").eq("user_id", data.userId).maybeSingle();
    return r;
  });

export const setChatRules = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => rulesSchema.parse(d))
  .handler(async ({ data, context }) => {
    const db = await owner(context);
    const { userId, ...rest } = data;
    const { error } = await db.from("chat_restrictions").upsert({ user_id: userId, ...rest, updated_at: new Date().toISOString() });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
