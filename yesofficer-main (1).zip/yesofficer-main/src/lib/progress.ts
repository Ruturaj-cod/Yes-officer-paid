export type LastWatched = { courseId: string; videoId: string; title: string; position: number; duration: number; at: number };
const KEY = "yo:last-watched";

export function getLastWatched(): LastWatched[] {
  try { return JSON.parse(localStorage.getItem(KEY) || "[]") as LastWatched[]; } catch { return []; }
}
export function saveProgress(e: Omit<LastWatched, "at">) {
  const list = getLastWatched().filter((x) => x.videoId !== e.videoId);
  list.unshift({ ...e, at: Date.now() });
  localStorage.setItem(KEY, JSON.stringify(list.slice(0, 10)));
}
export function getPosition(videoId: string) {
  return getLastWatched().find((x) => x.videoId === videoId)?.position ?? 0;
}
export function formatLectureTime(sec: number) {
  if (!sec) return "";
  return new Date(sec * 1000).toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "numeric", minute: "2-digit", hour12: true });
}
