import { createFileRoute } from "@tanstack/react-router";

const ALLOWED = [/\.classx\.co\.in$/, /\.cloud-front\.in$/, /\.appx\.co\.in$/, /\.cloudfront\.net$/];

function proxied(u: string) {
  return `/api/public/stream?url=${encodeURIComponent(u)}`;
}

export const Route = createFileRoute("/api/public/stream")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const target = new URL(request.url).searchParams.get("url");
        if (!target) return new Response("Missing url", { status: 400 });
        let url: URL;
        try {
          url = new URL(target);
        } catch {
          return new Response("Bad url", { status: 400 });
        }
        if (url.protocol !== "https:" || !ALLOWED.some((r) => r.test(url.hostname))) {
          return new Response("Host not allowed", { status: 403 });
        }
        const headers: Record<string, string> = {
          Referer: "https://appx-play.akamai.net.in/",
          Origin: "https://appx-play.akamai.net.in",
        };
        const range = request.headers.get("range");
        if (range) headers["Range"] = range;
        const upstream = await fetch(url.toString(), { headers });
        const ct = upstream.headers.get("content-type") ?? "";
        const isPlaylist = url.pathname.endsWith(".m3u8") || ct.includes("mpegurl");
        const cors = { "Access-Control-Allow-Origin": "*" };
        if (isPlaylist && upstream.ok) {
          const text = await upstream.text();
          const out = text
            .split("\n")
            .map((line) => {
              const t = line.trim();
              if (!t) return line;
              if (t.startsWith("#")) {
                return line.replace(/URI="([^"]+)"/g, (_, u) => `URI="${proxied(new URL(u, url).toString())}"`);
              }
              return proxied(new URL(t, url).toString());
            })
            .join("\n");
          return new Response(out, {
            headers: { ...cors, "Content-Type": "application/vnd.apple.mpegurl", "Cache-Control": "no-store" },
          });
        }
        const h = new Headers(cors);
        for (const k of ["content-type", "content-length", "content-range", "accept-ranges", "cache-control"]) {
          const v = upstream.headers.get(k);
          if (v) h.set(k, v);
        }
        return new Response(upstream.body, { status: upstream.status, headers: h });
      },
    },
  },
});
