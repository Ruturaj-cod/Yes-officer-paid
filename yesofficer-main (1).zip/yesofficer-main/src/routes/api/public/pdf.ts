import { createFileRoute } from "@tanstack/react-router";

const ALLOWED_HOSTS = [
  "appxcontent.kycapp.co.in",
  "appxcontent-v2.classx.co.in",
  "appx-bank-s3.ap-south-1.amazonaws.com",
  "player.vimeo.com",
  "static-db-v2.appx.co.in",
  "static-db.appx.co.in",
  "pdfweb.classx.co.in",
];

export const Route = createFileRoute("/api/public/pdf")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const reqUrl = new URL(request.url);
        const target = reqUrl.searchParams.get("url");
        if (!target) return new Response("Missing url", { status: 400 });

        let upstream: URL;
        try {
          upstream = new URL(target);
        } catch {
          return new Response("Invalid url", { status: 400 });
        }
        if (
          upstream.protocol !== "https:" ||
          !ALLOWED_HOSTS.includes(upstream.hostname)
        ) {
          return new Response("Host not allowed", { status: 403 });
        }

        const range = request.headers.get("range");
        const headers: Record<string, string> = {
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36",
          Referer: "https://appx-play.akamai.net.in/",
          Accept: "application/pdf,*/*",
        };
        if (range) headers["Range"] = range;

        let res: Response;
        try {
          res = await fetch(upstream.toString(), {
            headers,
            redirect: "follow",
          });
        } catch (e) {
          return new Response(`Upstream fetch failed: ${String(e)}`, {
            status: 502,
          });
        }
        if (!res.ok && res.status !== 206) {
          return new Response(`Upstream error ${res.status}`, {
            status: res.status,
          });
        }

        const out = new Headers();
        const copy = [
          "content-type",
          "content-length",
          "content-range",
          "accept-ranges",
        ];
        for (const k of copy) {
          const v = res.headers.get(k);
          if (v) out.set(k, v);
        }
        if (!out.has("content-type"))
          out.set("content-type", "application/pdf");
        const name = (reqUrl.searchParams.get("name") || "notes").replace(
          /[^\w\- ]+/g,
          "",
        );
        out.set("content-disposition", `inline; filename="${name}.pdf"`);
        out.set("access-control-allow-origin", "*");
        out.set("cache-control", "public, max-age=300");

        return new Response(res.body, { status: res.status, headers: out });
      },
    },
  },
});
