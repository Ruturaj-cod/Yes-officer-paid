import { createFileRoute, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "YES OFFICER – Sign in" },
      { name: "description", content: "💝 This is a small gift from Ma’am’s side, absolutely FREE OF COST for everyone! 🥹❤️" },
      { property: "og:title", content: "YES OFFICER – Sign in" },
      { property: "og:description", content: "💝 This is a small gift from Ma’am’s side, absolutely FREE OF COST for everyone! 🥹❤️" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    throw redirect({ to: data.session ? "/home" : "/auth", replace: true });
  },
  component: () => null,
});
