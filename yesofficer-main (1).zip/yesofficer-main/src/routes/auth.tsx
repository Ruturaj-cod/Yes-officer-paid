import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { Lock, User } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { claimDevice, hasOwner, setupOwner } from "@/lib/auth.functions";
import { usernameToEmail } from "@/lib/access";

export const Route = createFileRoute("/auth")({
  validateSearch: z.object({ reason: z.enum(["replaced", "suspended"]).optional() }),
  ssr: false,
  head: () => ({
    meta: [
      { title: "Sign in – YES OFFICER" },
      { name: "description", content: "💝 This is a small gift from Ma’am’s side, absolutely FREE OF COST for everyone! 🥹❤️" },
      { property: "og:title", content: "Sign in – YES OFFICER" },
      { property: "og:description", content: "💝 This is a small gift from Ma’am’s side, absolutely FREE OF COST for everyone! 🥹❤️" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

const REASONS = {
  replaced: "You were signed out because your account was signed in on another device.",
  suspended: "Your account is suspended. Please contact the admin.",
};

function AuthPage() {
  const { reason } = Route.useSearch();
  const navigate = useNavigate();
  const [setup, setSetup] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    hasOwner().then((h) => setSetup(!h)).catch(() => {});
    supabase.auth.getSession().then(({ data }) => { if (data.session && !reason) navigate({ to: "/home", replace: true }); });
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(""); setBusy(true);
    try {
      if (setup) await setupOwner({ data: { username, password, name } });
      const { error } = await supabase.auth.signInWithPassword({ email: usernameToEmail(username), password });
      if (error) throw new Error("Wrong username or password");
      try {
        await claimDevice();
      } catch (e) {
        await supabase.auth.signOut();
        throw new Error(String((e as Error).message).includes("SUSPENDED") ? REASONS.suspended : "This account can't sign in.");
      }
      navigate({ to: setup ? "/admin" : "/home", replace: true });
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="bg-hero grid min-h-screen place-items-center px-4">
      <form onSubmit={submit} className="w-full max-w-sm space-y-4 rounded-3xl border border-border bg-card p-6 text-foreground shadow-card">
        <div className="flex flex-col items-center gap-2 text-center">
          <span className="h-12 w-12 overflow-hidden rounded-2xl bg-primary"><img src="/logo.png" alt="YES OFFICER logo" className="h-full w-full object-cover" /></span>
          <h1 className="text-xl font-extrabold">{setup ? "Create owner account" : "Sign in to YES OFFICER"}</h1>
          <p className="text-xs text-muted-foreground">{setup ? "First-time setup. This account will manage all students." : "Use the login details given by your admin."}</p>
        </div>
        {reason && !setup && <p className="rounded-xl bg-accent/20 p-3 text-xs font-semibold">{REASONS[reason]}</p>}
        {setup && (
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" className="h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
        )}
        <label className="relative block">
          <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input required autoComplete="username" autoCapitalize="none" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" className="h-11 w-full rounded-xl border border-input bg-background pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
        </label>
        <label className="relative block">
          <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input required type="password" autoComplete={setup ? "new-password" : "current-password"} minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="h-11 w-full rounded-xl border border-input bg-background pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
        </label>
        {err && <p className="text-xs font-semibold text-destructive">{err}</p>}
        <button disabled={busy} className="h-11 w-full rounded-xl bg-primary text-sm font-bold text-primary-foreground disabled:opacity-60">
          {busy ? "Please wait…" : setup ? "Create & sign in" : "Sign in"}
        </button>
        {!setup && <p className="text-center text-[11px] text-muted-foreground">No account? Ask your admin to create one for you.</p>}
      </form>
    </div>
  );
}
