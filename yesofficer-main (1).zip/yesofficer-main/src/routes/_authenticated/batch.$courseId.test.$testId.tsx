import { createFileRoute, useRouter } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery, useQuery } from "@tanstack/react-query";
import { ChevronLeft, Clock, Flag, CheckCircle2, XCircle } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { fetchTestCached, type TestDetail } from "@/lib/yoapi";
import { SiteHeader } from "@/components/SiteHeader";
import { meQuery, useLogAccess } from "@/lib/me";
import { canOpenBatch } from "@/lib/access";
import { NoAccess } from "@/components/NoAccess";
import { cn } from "@/lib/utils";

const testQuery = (courseId: string, testId: string) =>
  queryOptions({
    queryKey: ["test", courseId, testId],
    queryFn: () => fetchTestCached(courseId, testId),
    staleTime: Infinity,
  });

export const Route = createFileRoute("/_authenticated/batch/$courseId/test/$testId")({
  ssr: false,
  loader: ({ context, params }) =>
    context.queryClient.ensureQueryData(testQuery(params.courseId, params.testId)),
  head: ({ loaderData }) => {
    const title = loaderData?.title ? `${loaderData.title} – YES OFFICER` : "Test – YES OFFICER";
    return {
      meta: [
        { title },
        { name: "description", content: "Attempt the test with a timer and see your score." },
        { property: "og:title", content: title },
        { property: "og:description", content: "Attempt the test with a timer and see your score." },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary" },
      ],
    };
  },
  pendingComponent: () => (
    <div className="min-h-screen"><SiteHeader /><div className="mx-auto max-w-3xl space-y-3 px-4 py-6"><div className="h-40 animate-pulse rounded-2xl bg-muted" /></div></div>
  ),
  errorComponent: ({ error }) => (
    <div className="min-h-screen"><SiteHeader /><p className="p-8 text-center text-sm text-destructive">{(error as Error).message}</p></div>
  ),
  component: TestPage,
});

function TestPage() {
  const { courseId } = Route.useParams();
  const { data: me } = useQuery(meQuery);
  if (me && !canOpenBatch(courseId, me.courseIds, me.isAdmin)) return <NoAccess />;
  if (!me) return null;
  return <TestView />;
}

const fmt = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

function TestView() {
  const { courseId, testId } = Route.useParams();
  const { data: test } = useSuspenseQuery(testQuery(courseId, testId));
  const router = useRouter();
  const [started, setStarted] = useState(false);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(test.minutes * 60);
  useLogAccess({ courseId, itemId: testId, itemTitle: test.title, kind: "test" });

  useEffect(() => {
    if (!started || submitted || !test.minutes) return;
    const t = setInterval(() => setSecondsLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [started, submitted, test.minutes]);

  useEffect(() => {
    if (started && !submitted && test.minutes && secondsLeft === 0) setSubmitted(true);
  }, [secondsLeft, started, submitted, test.minutes]);

  const answered = Object.keys(answers).length;
  const score = useMemo(
    () => test.questions.reduce((n, q, i) => n + (q.answer > 0 && answers[i] === q.answer ? 1 : 0), 0),
    [submitted, answers, test],
  );

  if (!started) {
    return (
      <div className="min-h-screen pb-24">
        <SiteHeader />
        <main className="mx-auto max-w-3xl px-4 py-5">
          <button onClick={() => router.history.back()} className="mb-4 flex items-center rounded-lg bg-secondary px-2 py-1 text-xs font-semibold text-secondary-foreground">
            <ChevronLeft className="h-4 w-4" /> Back
          </button>
          <div className="rounded-2xl border border-border bg-card p-6 text-center shadow-card">
            <h1 className="text-lg font-extrabold leading-snug">{test.title}</h1>
            <div className="mt-4 flex justify-center gap-6 text-sm font-semibold text-muted-foreground">
              <span>{test.questions.length} questions</span>
              {test.minutes > 0 && <span>{test.minutes} mins</span>}
              {test.totalMarks > 0 && <span>{test.totalMarks} marks</span>}
            </div>
            <button
              onClick={() => setStarted(true)}
              className="mt-6 w-full rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground"
            >
              Start test
            </button>
          </div>
        </main>
      </div>
    );
  }

  if (submitted) return <ResultView test={test} answers={answers} score={score} onRetry={() => { setAnswers({}); setCurrent(0); setSecondsLeft(test.minutes * 60); setSubmitted(false); }} />;

  const q = test.questions[current]!;
  return (
    <div className="min-h-screen pb-24">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-5">
        <div className="mb-4 flex items-center justify-between gap-2">
          <span className="text-xs font-bold text-muted-foreground">
            Question {current + 1} / {test.questions.length}
          </span>
          {test.minutes > 0 && (
            <span className={cn("flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-bold", secondsLeft < 60 ? "bg-destructive text-destructive-foreground" : "bg-secondary text-secondary-foreground")}>
              <Clock className="h-3.5 w-3.5" /> {fmt(secondsLeft)}
            </span>
          )}
        </div>

        <div className="rounded-2xl border border-border bg-card p-4 shadow-card">
          <div className="prose-sm max-w-none text-sm font-semibold leading-relaxed" dangerouslySetInnerHTML={{ __html: q.html }} />
          <div className="mt-4 space-y-2">
            {q.options.map((opt, oi) => {
              const n = oi + 1;
              const sel = answers[current] === n;
              return (
                <button
                  key={oi}
                  onClick={() => setAnswers((a) => ({ ...a, [current]: n }))}
                  className={cn(
                    "flex w-full items-start gap-3 rounded-xl border p-3 text-left text-sm font-medium",
                    sel ? "border-primary bg-primary/10 text-foreground" : "border-border bg-background text-foreground",
                  )}
                >
                  <span className={cn("grid h-6 w-6 shrink-0 place-items-center rounded-full border text-[11px] font-bold", sel ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground")}>
                    {String.fromCharCode(65 + oi)}
                  </span>
                  <span className="flex-1" dangerouslySetInnerHTML={{ __html: opt }} />
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between gap-2">
          <button
            onClick={() => setCurrent((c) => Math.max(0, c - 1))}
            disabled={current === 0}
            className="rounded-xl bg-secondary px-4 py-2.5 text-sm font-bold text-secondary-foreground disabled:opacity-40"
          >
            Previous
          </button>
          {current < test.questions.length - 1 ? (
            <button onClick={() => setCurrent((c) => c + 1)} className="rounded-xl bg-primary px-6 py-2.5 text-sm font-bold text-primary-foreground">
              Next
            </button>
          ) : (
            <button
              onClick={() => setSubmitted(true)}
              className="flex items-center gap-1.5 rounded-xl bg-success px-5 py-2.5 text-sm font-bold text-success-foreground"
            >
              <Flag className="h-4 w-4" /> Submit
            </button>
          )}
        </div>

        <div className="mt-5">
          <p className="mb-2 text-xs font-bold text-muted-foreground">{answered} of {test.questions.length} answered</p>
          <div className="flex flex-wrap gap-1.5">
            {test.questions.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={cn(
                  "grid h-8 w-8 place-items-center rounded-lg border text-[11px] font-bold",
                  i === current
                    ? "border-primary bg-primary text-primary-foreground"
                    : answers[i]
                      ? "border-success/50 bg-success/15 text-success"
                      : "border-border bg-card text-muted-foreground",
                )}
              >
                {i + 1}
              </button>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

function ResultView({ test, answers, score, onRetry }: { test: TestDetail; answers: Record<number, number>; score: number; onRetry: () => void }) {
  const router = useRouter();
  const known = test.questions.filter((q) => q.answer > 0).length;
  return (
    <div className="min-h-screen pb-24">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-5">
        <div className="rounded-2xl border border-border bg-card p-6 text-center shadow-card">
          <h1 className="text-lg font-extrabold">{test.title}</h1>
          <p className="mt-3 text-4xl font-extrabold text-primary">{score}<span className="text-base text-muted-foreground"> / {known || test.questions.length}</span></p>
          <p className="mt-1 text-xs font-semibold text-muted-foreground">
            {known ? "Correct answers" : "Answer key not provided by the source — review below"}
          </p>
          <div className="mt-5 flex gap-2">
            <button onClick={onRetry} className="flex-1 rounded-xl bg-secondary px-4 py-2.5 text-sm font-bold text-secondary-foreground">Retry</button>
            <button onClick={() => router.history.back()} className="flex-1 rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground">Done</button>
          </div>
        </div>

        <h2 className="mb-2 mt-6 text-sm font-bold uppercase tracking-wider text-muted-foreground">Review</h2>
        <div className="space-y-3">
          {test.questions.map((q, i) => {
            const mine = answers[i];
            const right = q.answer > 0 && mine === q.answer;
            const wrong = q.answer > 0 && mine != null && mine !== q.answer;
            return (
              <div key={q.id} className="rounded-2xl border border-border bg-card p-4 shadow-card">
                <div className="flex items-start gap-2">
                  {right ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-success" /> : wrong ? <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" /> : <span className="mt-0.5 h-4 w-4 shrink-0" />}
                  <div className="prose-sm max-w-none text-sm font-semibold leading-relaxed" dangerouslySetInnerHTML={{ __html: q.html }} />
                </div>
                <div className="mt-3 space-y-1.5">
                  {q.options.map((opt, oi) => {
                    const n = oi + 1;
                    const isAns = q.answer === n;
                    const isMine = mine === n;
                    return (
                      <div
                        key={oi}
                        className={cn(
                          "rounded-lg border px-3 py-2 text-xs font-medium",
                          isAns ? "border-success/60 bg-success/10 text-success" : isMine ? "border-destructive/60 bg-destructive/10 text-destructive" : "border-border text-muted-foreground",
                        )}
                      >
                        <span className="mr-1.5 font-bold">{String.fromCharCode(65 + oi)}.</span>
                        <span dangerouslySetInnerHTML={{ __html: opt }} />
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}
