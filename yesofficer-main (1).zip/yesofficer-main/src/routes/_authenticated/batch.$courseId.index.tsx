import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { ChevronLeft, Folder, PlayCircle, Image as ImageIcon, FileText, ClipboardList } from "lucide-react";
import { z } from "zod";
import { toast } from "sonner";
import { fetchFolderCached, fetchLiveClasses } from "@/lib/yoapi";
import { SiteHeader, WhatsAppFab } from "@/components/SiteHeader";
import { PdfRow } from "@/components/PdfReader";
import { useQuery } from "@tanstack/react-query";
import { meQuery, useLogAccess } from "@/lib/me";
import { canOpenBatch } from "@/lib/access";
import { NoAccess } from "@/components/NoAccess";
import { formatLectureTime } from "@/lib/progress";

const folderQuery = (courseId: string, parentId: string) =>
  queryOptions({
    queryKey: ["folder", courseId, parentId],
    queryFn: () => fetchFolderCached(courseId, parentId),
    staleTime: 5 * 60_000,
  });

const liveQuery = (courseId: string) =>
  queryOptions({
    queryKey: ["live-classes", courseId],
    queryFn: () => fetchLiveClasses(courseId),
    staleTime: 2 * 60_000,
  });

const search = z.object({
  parent: z.string().optional(),
  trail: z.string().optional(),
});

export const Route = createFileRoute("/_authenticated/batch/$courseId/")({
  validateSearch: search,
  ssr: false,
  loaderDeps: ({ search }) => ({ parent: search.parent ?? "-1" }),
  loader: ({ context, params, deps }) =>
    context.queryClient.ensureQueryData(folderQuery(params.courseId, deps.parent)),
  head: () => ({
    meta: [
      { title: "Batch contents – YES OFFICER" },
      { name: "description", content: "Subjects, topic folders, lecture videos and notes for this YES OFFICER batch." },
      { property: "og:title", content: "Batch contents – YES OFFICER" },
      { property: "og:description", content: "Subjects, topic folders, lecture videos and notes for this YES OFFICER batch." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  pendingComponent: () => (
    <div className="min-h-screen"><SiteHeader /><div className="mx-auto max-w-3xl space-y-3 px-4 py-6">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-muted" />)}</div></div>
  ),
  errorComponent: ({ error }) => (
    <div className="min-h-screen"><SiteHeader /><p className="p-8 text-center text-sm text-destructive">{(error as Error).message}</p></div>
  ),
  component: FolderPage,
});

type Crumb = { id: string; t: string };

function FolderPage() {
  const { courseId } = Route.useParams();
  const { data: me } = useQuery(meQuery);
  if (me && !canOpenBatch(courseId, me.courseIds, me.isAdmin)) return <NoAccess />;
  if (!me) return null;
  return <FolderView />;
}

function FolderView() {
  const { courseId } = Route.useParams();
  const { parent = "-1", trail } = Route.useSearch();
  const { data } = useSuspenseQuery(folderQuery(courseId, parent));
  const crumbs: Crumb[] = trail ? (JSON.parse(trail) as Crumb[]) : [];
  const into = (c: Crumb) => JSON.stringify([...crumbs, c]);
  const back = crumbs.slice(0, -1);
  const backParent = back[back.length - 1]?.id;
  const last = crumbs[crumbs.length - 1];
  useLogAccess({ courseId, itemId: parent, itemTitle: last?.t ?? "Batch home", kind: last ? "folder" : "batch" });

  return (
    <div className="min-h-screen pb-24">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-5">
        <div className="mb-4 flex items-center gap-2 overflow-x-auto text-xs font-semibold text-muted-foreground">
          {crumbs.length ? (
            <Link to="/batch/$courseId" params={{ courseId }} search={{ parent: backParent, trail: back.length ? JSON.stringify(back) : undefined }} className="flex shrink-0 items-center rounded-lg bg-secondary px-2 py-1 text-secondary-foreground">
              <ChevronLeft className="h-4 w-4" /> Back
            </Link>
          ) : (
            <Link to="/home" className="flex shrink-0 items-center rounded-lg bg-secondary px-2 py-1 text-secondary-foreground"><ChevronLeft className="h-4 w-4" /> Batches</Link>
          )}
          <Link to="/batch/$courseId" params={{ courseId }} className="shrink-0 hover:text-primary">Home</Link>
          {crumbs.map((c, i) => (
            <span key={c.id} className="flex shrink-0 items-center gap-2">
              /
              <Link to="/batch/$courseId" params={{ courseId }} search={{ parent: c.id, trail: JSON.stringify(crumbs.slice(0, i + 1)) }} className="max-w-[10rem] truncate hover:text-primary">{c.t}</Link>
            </span>
          ))}
        </div>

        <h1 className="mb-4 text-xl font-extrabold">{crumbs[crumbs.length - 1]?.t ?? "Batch contents"}</h1>

        {parent === "-1" && <LiveNow courseId={courseId} />}


        <div className="space-y-2">
          {data.map((it) => {
            if (it.type === "FOLDER") {
              return (
                <Link key={it.id} to="/batch/$courseId" params={{ courseId }} search={{ parent: it.id, trail: into({ id: it.id, t: it.title }) }} className="flex items-center gap-3 rounded-xl border border-border bg-card p-3 shadow-card hover:border-primary">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-accent/20 text-accent-foreground"><Folder className="h-5 w-5" /></span>
                  <span className="flex-1 text-sm font-semibold">{it.title}</span>
                </Link>
              );
            }
            if (it.type === "VIDEO") {
              return (
                <Link key={it.id} to="/batch/$courseId/video/$videoId" params={{ courseId, videoId: it.id }} search={{ t: it.title }} className="flex items-center gap-3 rounded-xl border border-border bg-card p-3 shadow-card hover:border-primary">
                  {it.thumbnail ? (
                    <img src={it.thumbnail} alt="" loading="lazy" className="h-12 w-20 shrink-0 rounded-lg object-cover" />
                  ) : (
                    <span className="grid h-12 w-20 shrink-0 place-items-center rounded-lg bg-primary text-primary-foreground"><PlayCircle className="h-5 w-5" /></span>
                  )}
                  <span className="min-w-0 flex-1">
                    <span className="block break-words text-sm font-semibold">{it.title}</span>
                    {it.time > 0 && (
                      <span className="mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-1 text-[11px] font-medium text-muted-foreground">
                        {it.live && (
                          <span className="inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded bg-destructive px-1.5 py-0.5 text-[10px] font-bold uppercase leading-none text-destructive-foreground">
                            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-destructive-foreground" /> Live now
                          </span>
                        )}
                        {it.upcoming && <span className="shrink-0 whitespace-nowrap rounded bg-accent px-1.5 py-0.5 text-[10px] font-bold uppercase leading-none text-accent-foreground">Upcoming</span>}
                        <span className="whitespace-nowrap">{formatLectureTime(it.time)}</span>
                      </span>
                    )}
                  </span>
                  <PlayCircle className="h-5 w-5 shrink-0 text-primary" />
                </Link>
              );
            }
            if (it.pdfs.length) {
              return <div key={it.id} className="space-y-2">{it.pdfs.map((p) => <PdfRow key={p.url} pdf={p} title={it.title} />)}</div>;
            }
            if (it.type === "IMAGE" && it.fileUrl) {
              return (
                <a key={it.id} href={it.fileUrl} target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-xl border border-border bg-card p-3 shadow-card">
                  <span className="grid h-10 w-10 place-items-center rounded-lg bg-success/15 text-success"><ImageIcon className="h-5 w-5" /></span>
                  <span className="flex-1 text-sm font-semibold">{it.title}</span>
                </a>
              );
            }
            if (it.type === "TEST" && it.quizId) {
              return (
                <Link key={it.id} to="/batch/$courseId/test/$testId" params={{ courseId, testId: it.quizId }} className="flex items-center gap-3 rounded-xl border border-border bg-card p-3 shadow-card hover:border-primary">
                  <span className="grid h-10 w-10 place-items-center rounded-lg bg-accent/20 text-accent-foreground"><ClipboardList className="h-5 w-5" /></span>
                  <span className="min-w-0 flex-1">
                    <span className="block break-words text-sm font-semibold">{it.title}</span>
                    {it.time > 0 && <span className="mt-1 block text-[11px] font-medium text-muted-foreground">{formatLectureTime(it.time)}</span>}
                  </span>
                  <span className="shrink-0 rounded-lg bg-primary px-2.5 py-1 text-[10px] font-bold uppercase text-primary-foreground">Start test</span>
                </Link>
              );
            }
            return (
              <button
                key={it.id}
                type="button"
                onClick={() => toast.info("Contact admin to access this content.")}
                className="flex w-full items-center gap-3 rounded-xl border border-border bg-card p-3 text-left opacity-80"
              >
                <span className="grid h-10 w-10 place-items-center rounded-lg bg-muted text-muted-foreground">{it.type === "PDF" ? <FileText className="h-5 w-5" /> : <ClipboardList className="h-5 w-5" />}</span>
                <span className="flex-1 text-sm font-semibold">{it.title}</span>
                <span className="text-[10px] font-bold uppercase text-muted-foreground">{it.type}</span>
              </button>
            );
          })}
          {!data.length && <p className="py-16 text-center text-sm text-muted-foreground">This folder is empty.</p>}
        </div>
      </main>
      <WhatsAppFab />
    </div>
  );
}

/** Live & upcoming classes pinned at the top of the batch home page. */
function LiveNow({ courseId }: { courseId: string }) {
  const { data } = useQuery(liveQuery(courseId));
  const list = data ?? [];
  if (!list.length) return null;
  return (
    <section className="mb-5">
      <h2 className="mb-2 flex items-center gap-2 text-sm font-extrabold">
        <span className="h-2 w-2 animate-pulse rounded-full bg-destructive" /> Live & upcoming classes
      </h2>
      <div className="space-y-2">
        {list.map((it) => (
          <Link
            key={it.id}
            to="/batch/$courseId/video/$videoId"
            params={{ courseId, videoId: it.id }}
            search={{ t: it.title }}
            className="flex items-center gap-3 rounded-xl border border-destructive/40 bg-card p-3 shadow-card hover:border-destructive"
          >
            {it.thumbnail ? (
              <img src={it.thumbnail} alt="" loading="lazy" className="h-12 w-20 shrink-0 rounded-lg object-cover" />
            ) : (
              <span className="grid h-12 w-20 shrink-0 place-items-center rounded-lg bg-destructive text-destructive-foreground"><PlayCircle className="h-5 w-5" /></span>
            )}
            <span className="min-w-0 flex-1">
              <span className="block break-words text-sm font-semibold">{it.title}</span>
              <span className="mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-1 text-[11px] font-medium text-muted-foreground">
                {it.live && (
                  <span className="inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded bg-destructive px-1.5 py-0.5 text-[10px] font-bold uppercase leading-none text-destructive-foreground">
                    <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-destructive-foreground" /> Live now — tap to join
                  </span>
                )}
                {it.upcoming && <span className="shrink-0 whitespace-nowrap rounded bg-accent px-1.5 py-0.5 text-[10px] font-bold uppercase leading-none text-accent-foreground">Upcoming</span>}
                {it.time > 0 && <span className="whitespace-nowrap">{formatLectureTime(it.time)}</span>}
              </span>
            </span>
            <PlayCircle className="h-5 w-5 shrink-0 text-destructive" />
          </Link>
        ))}
      </div>
    </section>
  );
}
