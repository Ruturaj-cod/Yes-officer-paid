import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { BookOpen, ChevronRight, LogOut, Shield, Smartphone } from "lucide-react";
import { meQuery, useSignOut } from "@/lib/me";
import { batchesQuery } from "./home";
import { visibleBatches } from "@/lib/access";
import { SiteHeader, WhatsAppFab, WHATSAPP_URL } from "@/components/SiteHeader";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "My profile – YES OFFICER" },
      { name: "description", content: "Your YES OFFICER account, assigned batches and sign-out." },
      { property: "og:title", content: "My profile – YES OFFICER" },
      { property: "og:description", content: "Your YES OFFICER account, assigned batches and sign-out." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Profile,
});

function Profile() {
  const { data: me } = useQuery(meQuery);
  const { data: batches = [] } = useQuery(batchesQuery);
  const signOut = useSignOut();
  const mine = me ? visibleBatches(batches, me.courseIds, me.isAdmin) : [];
  const name = me?.displayName || me?.username || "";

  return (
    <div className="min-h-screen pb-24">
      <SiteHeader />
      <main className="mx-auto max-w-xl space-y-5 px-4 py-6">
        <div className="flex items-center gap-4 rounded-2xl bg-secondary p-4">
          <span className="grid h-14 w-14 place-items-center rounded-full bg-primary text-xl font-extrabold text-primary-foreground">{name.charAt(0).toUpperCase() || "?"}</span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-lg font-bold">{name}</p>
            <p className="text-sm text-muted-foreground">Welcome back! · @{me?.username}</p>
          </div>
          {me?.isAdmin && <span className="rounded-full bg-accent px-2 py-1 text-[10px] font-bold uppercase text-accent-foreground">Owner</span>}
        </div>

        <nav className="divide-y divide-border rounded-2xl border border-border bg-card">
          <Link to="/home" className="flex items-center gap-3 p-4 text-sm font-semibold"><BookOpen className="h-4 w-4 text-primary" /> My batches <span className="ml-auto text-xs text-muted-foreground">{mine.length}</span><ChevronRight className="h-4 w-4 text-muted-foreground" /></Link>
          {me?.isAdmin && <Link to="/admin" className="flex items-center gap-3 p-4 text-sm font-semibold"><Shield className="h-4 w-4 text-primary" /> Owner panel<ChevronRight className="ml-auto h-4 w-4 text-muted-foreground" /></Link>}
          <a href={WHATSAPP_URL} target="_blank" rel="noreferrer" className="flex items-center gap-3 p-4 text-sm font-semibold"><span className="h-4 w-4 rounded-full bg-whatsapp" /> WhatsApp channel<ChevronRight className="ml-auto h-4 w-4 text-muted-foreground" /></a>
          <div className="flex items-center gap-3 p-4 text-sm"><Smartphone className="h-4 w-4 text-primary" /><span className="font-semibold">This device</span><span className="ml-auto text-xs text-muted-foreground">Only one device can be signed in</span></div>
        </nav>

        {mine.length > 0 && (
          <section>
            <h2 className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">Assigned batches</h2>
            <div className="space-y-2">
              {mine.map((b) => (
                <Link key={b.id} to="/batch/$courseId" params={{ courseId: b.id }} className="flex items-center gap-3 rounded-xl border border-border bg-card p-3 text-sm font-semibold">
                  <span className="line-clamp-1 flex-1">{b.title}</span><ChevronRight className="h-4 w-4 text-muted-foreground" />
                </Link>
              ))}
            </div>
          </section>
        )}

        <button onClick={signOut} className="flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-destructive/40 bg-destructive/10 text-sm font-bold text-destructive">
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </main>
      <WhatsAppFab />
    </div>
  );
}
