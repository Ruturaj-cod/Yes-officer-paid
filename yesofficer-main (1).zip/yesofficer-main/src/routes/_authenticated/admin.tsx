import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { KeyRound, Search, UserPlus, Ban, CheckCircle2, ChevronDown, ShieldCheck } from "lucide-react";
import { meQuery } from "@/lib/me";
import { batchesQuery } from "./home";
import { createUser, listUsers, resetPassword, searchLogs, setAdmin, setAllBatchAccess, setBatchAccess, setSuspended } from "@/lib/admin.functions";
import { SiteHeader } from "@/components/SiteHeader";
import { NoAccess } from "@/components/NoAccess";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Owner panel – YES OFFICER" },
      { name: "description", content: "Manage student accounts, batch access and access history." },
      { property: "og:title", content: "Owner panel – YES OFFICER" },
      { property: "og:description", content: "Manage student accounts, batch access and access history." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Admin,
});

const input = "h-10 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring";

function Admin() {
  const { data: me } = useQuery(meQuery);
  const [tab, setTab] = useState<"users" | "logs">("users");
  if (!me) return null;
  if (!me.isAdmin) return <NoAccess />;
  return (
    <div className="min-h-screen pb-16">
      <SiteHeader />
      <main className="mx-auto max-w-4xl px-4 py-6">
        <h1 className="text-2xl font-extrabold">Owner panel</h1>
        <div className="my-4 inline-flex rounded-xl bg-secondary p-1">
          {(["users", "logs"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`rounded-lg px-4 py-2 text-sm font-bold ${tab === t ? "bg-primary text-primary-foreground" : "text-secondary-foreground"}`}>
              {t === "users" ? "Students" : "Access history"}
            </button>
          ))}
        </div>
        {tab === "users" ? <Users /> : <Logs />}
      </main>
    </div>
  );
}

function Users() {
  const qc = useQueryClient();
  const users = useQuery({ queryKey: ["admin-users"], queryFn: () => listUsers() });
  const [form, setForm] = useState({ name: "", username: "", password: "" });
  const [msg, setMsg] = useState("");
  const create = useMutation({
    mutationFn: () => createUser({ data: form }),
    onSuccess: () => { setMsg(`Created ${form.username}. Share the username and password with the student.`); setForm({ name: "", username: "", password: "" }); qc.invalidateQueries({ queryKey: ["admin-users"] }); },
    onError: (e) => setMsg((e as Error).message),
  });

  return (
    <div className="space-y-5">
      <form onSubmit={(e) => { e.preventDefault(); create.mutate(); }} className="space-y-3 rounded-2xl border border-border bg-card p-4">
        <h2 className="flex items-center gap-2 text-sm font-bold"><UserPlus className="h-4 w-4" /> Create student account</h2>
        <div className="grid gap-2 sm:grid-cols-3">
          <input className={input} placeholder="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input className={input} required placeholder="Username" autoCapitalize="none" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
          <input className={input} required minLength={6} placeholder="Password (min 6)" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        </div>
        <button disabled={create.isPending} className="h-10 rounded-xl bg-primary px-4 text-sm font-bold text-primary-foreground disabled:opacity-60">{create.isPending ? "Creating…" : "Create account"}</button>
        {msg && <p className="text-xs font-semibold text-muted-foreground">{msg}</p>}
      </form>

      {users.isLoading && <p className="text-sm text-muted-foreground">Loading students…</p>}
      {users.error && <p className="text-sm text-destructive">{(users.error as Error).message}</p>}
      <div className="space-y-2">
        {users.data?.map((u) => <UserRow key={u.id} u={u} />)}
      </div>
    </div>
  );
}

type U = Awaited<ReturnType<typeof listUsers>>[number];

function UserRow({ u }: { u: U }) {
  const qc = useQueryClient();
  const { data: batches = [] } = useQuery(batchesQuery);
  const [open, setOpen] = useState(false);
  const refresh = () => qc.invalidateQueries({ queryKey: ["admin-users"] });
  const suspend = useMutation({ mutationFn: () => setSuspended({ data: { userId: u.id, suspended: !u.suspended } }), onSuccess: refresh, onError: (e) => alert((e as Error).message) });
  const { data: me } = useQuery(meQuery);
  const role = useMutation({ mutationFn: () => setAdmin({ data: { userId: u.id, admin: !u.isAdmin } }), onSuccess: refresh, onError: (e) => alert((e as Error).message) });
  const access = useMutation({ mutationFn: (v: { courseId: string; grant: boolean }) => setBatchAccess({ data: { userId: u.id, ...v } }), onSuccess: refresh });
  const allAccess = useMutation({
    mutationFn: (grant: boolean) => setAllBatchAccess({ data: { userId: u.id, courseIds: batches.map((b) => b.id), grant } }),
    onSuccess: refresh,
    onError: (e) => alert((e as Error).message),
  });
  const reset = async () => {
    const pw = prompt(`New password for ${u.username} (min 6 characters):`);
    if (!pw) return;
    try { await resetPassword({ data: { userId: u.id, password: pw } }); alert("Password updated."); } catch (e) { alert((e as Error).message); }
  };

  return (
    <div className={`rounded-2xl border border-border bg-card ${u.suspended ? "opacity-70" : ""}`}>
      <div className="flex flex-wrap items-center gap-2 p-3">
        <span className="grid h-9 w-9 place-items-center rounded-full bg-primary text-sm font-bold text-primary-foreground">{(u.displayName || u.username).charAt(0).toUpperCase()}</span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold">{u.displayName} {u.isAdmin && <span className="ml-1 rounded bg-accent px-1.5 text-[10px] text-accent-foreground">OWNER</span>} {u.suspended && <span className="ml-1 rounded bg-destructive/15 px-1.5 text-[10px] text-destructive">SUSPENDED</span>}</p>
          <p className="text-xs text-muted-foreground">@{u.username} · {u.isAdmin ? "all batches" : `${u.courseIds.length} batches`}</p>
        </div>
        {u.username !== me?.username && (
          <button
            onClick={() => { if (confirm(u.isAdmin ? `Remove admin rights from ${u.username}?` : `Make ${u.username} an admin? They will get full owner-panel access.`)) role.mutate(); }}
            disabled={role.isPending}
            className="flex items-center gap-1 rounded-lg bg-accent px-2.5 py-1.5 text-xs font-bold text-accent-foreground disabled:opacity-60"
          >
            <ShieldCheck className="h-3.5 w-3.5" /> {u.isAdmin ? "Remove admin" : "Make admin"}
          </button>
        )}
        {!u.isAdmin && (
          <>
            <button onClick={() => setOpen(!open)} className="flex items-center gap-1 rounded-lg bg-secondary px-2.5 py-1.5 text-xs font-bold text-secondary-foreground">Batches <ChevronDown className={`h-3.5 w-3.5 transition-transform ${open ? "rotate-180" : ""}`} /></button>
            <button onClick={reset} className="flex items-center gap-1 rounded-lg bg-secondary px-2.5 py-1.5 text-xs font-bold text-secondary-foreground"><KeyRound className="h-3.5 w-3.5" /> Reset</button>
            <button onClick={() => suspend.mutate()} className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-bold ${u.suspended ? "bg-success/15 text-success" : "bg-destructive/10 text-destructive"}`}>
              {u.suspended ? <><CheckCircle2 className="h-3.5 w-3.5" /> Reactivate</> : <><Ban className="h-3.5 w-3.5" /> Suspend</>}
            </button>
          </>
        )}
      </div>
      {open && (
        <div className="border-t border-border p-3">
          <div className="mb-2 flex gap-2">
            <button
              onClick={() => allAccess.mutate(true)}
              disabled={allAccess.isPending || !batches.length}
              className="rounded-lg bg-primary px-3 py-1.5 text-xs font-bold text-primary-foreground disabled:opacity-60"
            >
              {allAccess.isPending ? "Saving…" : "All batches"}
            </button>
            <button
              onClick={() => { if (confirm(`Remove all batch access from ${u.username}?`)) allAccess.mutate(false); }}
              disabled={allAccess.isPending}
              className="rounded-lg bg-destructive/10 px-3 py-1.5 text-xs font-bold text-destructive disabled:opacity-60"
            >
              Remove all
            </button>
          </div>
          <div className="grid gap-1 sm:grid-cols-2">
          {batches.map((b) => {
            const on = u.courseIds.includes(b.id);
            return (
              <label key={b.id} className="flex cursor-pointer items-center gap-2 rounded-lg p-1.5 text-xs hover:bg-muted">
                <input type="checkbox" checked={on} disabled={access.isPending} onChange={() => access.mutate({ courseId: b.id, grant: !on })} className="h-4 w-4 accent-primary" />
                <span className="line-clamp-1">{b.title}</span>
              </label>
            );
          })}
          {!batches.length && <p className="text-xs text-muted-foreground">Loading batches…</p>}
          </div>
        </div>
      )}
    </div>
  );
}

function Logs() {
  const users = useQuery({ queryKey: ["admin-users"], queryFn: () => listUsers() });
  const { data: batches = [] } = useQuery(batchesQuery);
  const [f, setF] = useState({ q: "", userId: "", from: "", to: "" });
  const logs = useQuery({ queryKey: ["logs", f], queryFn: () => searchLogs({ data: f }) });
  const batchName = (id: string) => batches.find((b) => b.id === id)?.title ?? id;

  return (
    <div className="space-y-3">
      <div className="grid gap-2 sm:grid-cols-4">
        <label className="relative sm:col-span-2">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input className={`${input} pl-9`} placeholder="Search user, lecture, batch id…" value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} />
        </label>
        <select className={input} value={f.userId} onChange={(e) => setF({ ...f, userId: e.target.value })}>
          <option value="">All students</option>
          {users.data?.map((u) => <option key={u.id} value={u.id}>{u.username}</option>)}
        </select>
        <div className="flex gap-2">
          <input type="date" className={input} value={f.from} onChange={(e) => setF({ ...f, from: e.target.value })} aria-label="From date" />
          <input type="date" className={input} value={f.to} onChange={(e) => setF({ ...f, to: e.target.value })} aria-label="To date" />
        </div>
      </div>
      <div className="overflow-x-auto rounded-2xl border border-border bg-card">
        <table className="w-full text-left text-xs">
          <thead className="bg-secondary text-secondary-foreground"><tr><th className="p-2">When</th><th className="p-2">Student</th><th className="p-2">Type</th><th className="p-2">Content</th><th className="p-2">Batch</th></tr></thead>
          <tbody>
            {logs.data?.map((l) => (
              <tr key={l.id} className="border-t border-border">
                <td className="whitespace-nowrap p-2">{new Date(l.created_at).toLocaleString()}</td>
                <td className="p-2 font-semibold">{l.username}</td>
                <td className="p-2 capitalize">{l.kind}</td>
                <td className="p-2">{l.item_title}</td>
                <td className="p-2 text-muted-foreground">{l.course_id ? batchName(l.course_id) : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {logs.isLoading && <p className="p-4 text-center text-xs text-muted-foreground">Loading…</p>}
        {logs.data && !logs.data.length && <p className="p-4 text-center text-xs text-muted-foreground">No records found.</p>}
      </div>
      <p className="text-[11px] text-muted-foreground">Showing the latest 300 matching records.</p>
    </div>
  );
}
