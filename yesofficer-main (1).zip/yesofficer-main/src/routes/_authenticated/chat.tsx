import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { Paperclip, Send, Trash2, Ban } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { meQuery } from "@/lib/me";
import { deleteMessage, getMyChatRules, sendMessage } from "@/lib/chat.functions";
import { Avatar, uploadFile, useFileUrl } from "@/lib/files";
import { SiteHeader } from "@/components/SiteHeader";
import { chatBlockReason, type MediaType } from "@/lib/access";

export const Route = createFileRoute("/_authenticated/chat")({
  head: () => ({
    meta: [
      { title: "Group chat – YES OFFICER" },
      { name: "description", content: "Chat with fellow students and the owner." },
      { property: "og:title", content: "Group chat – YES OFFICER" },
      { property: "og:description", content: "Chat with fellow students and the owner." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Chat,
});

type Msg = { id: string; user_id: string; display_name: string; username: string; avatar_url: string; is_admin: boolean; body: string; media_url: string; media_type: string; created_at: string };

const messagesQuery = {
  queryKey: ["chat"],
  queryFn: async () => {
    const { data, error } = await supabase.from("chat_messages").select("*").order("created_at", { ascending: false }).limit(200);
    if (error) throw error;
    return (data as Msg[]).reverse();
  },
};

function Media({ m }: { m: Msg }) {
  const url = useFileUrl("chat", m.media_url);
  if (!url) return <div className="h-32 w-48 animate-pulse rounded-lg bg-muted" />;
  if (m.media_type === "image") return <img src={url} alt="" className="max-h-64 rounded-lg" />;
  if (m.media_type === "video") return <video src={url} controls playsInline controlsList="nodownload" className="max-h-64 rounded-lg" />;
  return <audio src={url} controls controlsList="nodownload" className="w-56" />;
}

function Chat() {
  const qc = useQueryClient();
  const { data: me } = useQuery(meQuery);
  const { data: msgs = [] } = useQuery(messagesQuery);
  const { data: rules } = useQuery({ queryKey: ["my-chat-rules"], queryFn: () => getMyChatRules(), refetchInterval: 30_000 });
  const [text, setText] = useState("");
  const [err, setErr] = useState("");
  const end = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const ch = supabase.channel("chat-room")
      .on("postgres_changes", { event: "*", schema: "public", table: "chat_messages" }, () => qc.invalidateQueries({ queryKey: ["chat"] }))
      .subscribe();
    return () => { void supabase.removeChannel(ch); };
  }, [qc]);
  useEffect(() => { end.current?.scrollIntoView(); }, [msgs.length]);

  const send = useMutation({
    mutationFn: async (v: { body: string; file?: File }) => {
      let mediaPath = "";
      let mediaType: MediaType = "";
      if (v.file) {
        mediaType = v.file.type.startsWith("image/") ? "image" : v.file.type.startsWith("video/") ? "video" : v.file.type.startsWith("audio/") ? "audio" : "";
        if (!mediaType) throw new Error("Only photos, videos and audio can be sent.");
      }
      const reason = chatBlockReason(rules, { body: v.body, mediaType }, me?.isAdmin);
      if (reason) throw new Error(reason);
      if (v.file && me) mediaPath = await uploadFile("chat", (await supabase.auth.getUser()).data.user!.id, v.file);
      await sendMessage({ data: { body: v.body, mediaPath, mediaType } });
    },
    onSuccess: () => { setText(""); setErr(""); qc.invalidateQueries({ queryKey: ["chat"] }); },
    onError: (e) => setErr((e as Error).message),
  });
  const del = useMutation({ mutationFn: (id: string) => deleteMessage({ data: { id } }), onSuccess: () => qc.invalidateQueries({ queryKey: ["chat"] }) });

  const banned = !me?.isAdmin && rules?.banned;
  const myId = msgs.find((m) => m.username === me?.username)?.user_id;

  return (
    <div className="flex h-dvh flex-col">
      <SiteHeader />
      <div className="border-b border-border bg-card px-4 py-2 text-center text-sm font-extrabold">Group chat</div>
      <main className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-2xl space-y-3 px-4 py-4">
          {msgs.map((m) => {
            const mine = m.user_id === myId;
            return (
              <div key={m.id} className={`flex gap-2 ${mine ? "flex-row-reverse" : ""}`}>
                <Avatar path={m.avatar_url} name={m.display_name || m.username} />
                <div className={`max-w-[78%] rounded-2xl px-3 py-2 ${mine ? "bg-primary text-primary-foreground" : "bg-card border border-border"}`}>
                  <p className="text-[11px] font-bold opacity-80">
                    {m.display_name || m.username}{m.is_admin && <span className="ml-1 rounded bg-accent px-1 text-[9px] text-accent-foreground">OWNER</span>}
                  </p>
                  {m.media_url && <div className="my-1"><Media m={m} /></div>}
                  {m.body && <p className="whitespace-pre-wrap break-words text-sm">{m.body}</p>}
                  <p className="mt-0.5 flex items-center justify-end gap-2 text-[10px] opacity-60">
                    {new Date(m.created_at).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "numeric", minute: "2-digit" })}
                    {me?.isAdmin && <button onClick={() => confirm("Delete this message?") && del.mutate(m.id)} aria-label="Delete"><Trash2 className="h-3 w-3" /></button>}
                  </p>
                </div>
              </div>
            );
          })}
          {!msgs.length && <p className="py-16 text-center text-sm text-muted-foreground">No messages yet. Say hello!</p>}
          <div ref={end} />
        </div>
      </main>
      <footer className="border-t border-border bg-card p-3">
        <div className="mx-auto max-w-2xl">
          {err && <p className="mb-2 text-xs font-semibold text-destructive">{err}</p>}
          {banned ? (
            <p className="flex items-center justify-center gap-2 py-2 text-sm font-semibold text-destructive"><Ban className="h-4 w-4" /> You are banned from sending messages.</p>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); if (text.trim()) send.mutate({ body: text }); }} className="flex items-center gap-2">
              <input ref={fileRef} type="file" accept="image/*,video/*,audio/*" hidden onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ""; if (f) send.mutate({ body: text, file: f }); }} />
              <button type="button" onClick={() => fileRef.current?.click()} aria-label="Attach" className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-secondary text-secondary-foreground"><Paperclip className="h-4 w-4" /></button>
              <input value={text} onChange={(e) => setText(e.target.value)} maxLength={2000} placeholder="Message" className="h-10 flex-1 rounded-full border border-input bg-background px-4 text-sm outline-none focus:ring-2 focus:ring-ring" />
              <button disabled={send.isPending} aria-label="Send" className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground disabled:opacity-60"><Send className="h-4 w-4" /></button>
            </form>
          )}
        </div>
      </footer>
    </div>
  );
}
