import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useQuery, useSuspenseQuery } from "@tanstack/react-query";
import { Search, BookOpen } from "lucide-react";
import { useMemo, useState } from "react";
import { fetchBatches } from "@/lib/yoapi";
import { visibleBatches } from "@/lib/access";
import { meQuery } from "@/lib/me";
import { SiteHeader, WhatsAppFab } from "@/components/SiteHeader";
import { ContinueLearning } from "@/components/HomeExtras";
import { Timetable } from "@/components/Timetable";

export const batchesQuery = queryOptions({
  queryKey: ["batches"],
  queryFn: fetchBatches,
  staleTime: 10 * 60_000,
});

export const Route = createFileRoute("/_authenticated/home")({
  head: () => ({
    meta: [
      { title: "My batches – YES OFFICER" },
      { name: "description", content: "Your assigned YES OFFICER batches, lecture videos and PDF notes." },
      { property: "og:title", content: "My batches – YES OFFICER" },
      { property: "og:description", content: "Your assigned YES OFFICER batches, lecture videos and PDF notes." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  pendingComponent: () => <div className="min-h-screen"><SiteHeader /><div className="bg-hero h-64" /><div className="mx-auto grid max-w-6xl gap-4 px-4 py-8 sm:grid-cols-2 lg:grid-cols-3">{Array.from({ length: 6 }).map((_, i) => <div key={i} className="aspect-video animate-pulse rounded-2xl bg-muted" />)}</div></div>,
  errorComponent: ({ error, reset }) => {
    const raw = (error as Error).message ?? "";
    const msg = raw === "Failed to fetch" || raw.includes("fetch")
      ? "Could not reach the content server. Check your internet connection and try again."
      : raw;
    return (
      <div className="min-h-screen">
        <SiteHeader />
        <div className="mx-auto max-w-sm px-4 py-20 text-center">
          <p className="text-sm text-destructive">{msg}</p>
          <button onClick={() => reset()} className="mt-4 h-11 rounded-xl bg-primary px-6 text-sm font-bold text-primary-foreground">Retry</button>
        </div>
      </div>
    );
  },
  loader: async ({ context }) => {
    await context.queryClient.ensureQueryData(meQuery);
    return context.queryClient.ensureQueryData(batchesQuery);
  },
  component: Home,
});

function Home() {
  const { data } = useSuspenseQuery(batchesQuery);
  const { data: me } = useQuery(meQuery);
  const [q, setQ] = useState("");
  const mine = useMemo(() => visibleBatches(data, me?.courseIds ?? [], !!me?.isAdmin), [data, me]);
  const list = useMemo(() => mine.filter((b) => b.title.toLowerCase().includes(q.toLowerCase())), [mine, q]);

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <section className="bg-hero text-primary-foreground">
        <div className="mx-auto max-w-6xl px-4 py-10 sm:py-14">
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-accent">Welcome{me?.displayName ? `, ${me.displayName}` : ""}</p>
          <h1 className="mt-2 text-[clamp(1.6rem,7vw,3rem)] font-extrabold leading-tight">Your batches,<br />one clean portal.</h1>
          <p className="mt-3 max-w-md text-sm opacity-80">Lecture videos and PDF notes — open any batch and start learning.</p>
          <div className="relative mt-6 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search batches, lessons, videos, PDFs…" className="h-12 w-full rounded-xl bg-card pl-10 pr-4 text-sm text-foreground outline-none ring-accent focus:ring-2" />
          </div>
        </div>
      </section>

      <main className="mx-auto max-w-6xl space-y-8 px-4 py-8">
        <Timetable batches={mine} />
        {!q && <ContinueLearning allowed={me?.isAdmin ? null : new Set(me?.courseIds ?? [])} />}
        <h2 className="relative z-10 !mb-0 text-sm font-extrabold">My batches</h2>
        <div className="!mt-3 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((b) => (
            <Link key={b.id} to="/batch/$courseId" params={{ courseId: b.id }} className="group block overflow-hidden rounded-2xl border border-border bg-card shadow-card transition-transform hover:-translate-y-0.5">
              <div className="aspect-video bg-secondary">
                {b.thumbnail ? <img src={b.thumbnail} alt={b.title} loading="lazy" className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-primary"><BookOpen className="h-8 w-8" /></div>}
              </div>
              <div className="p-4">
                <h2 className="line-clamp-2 text-sm font-bold leading-snug">{b.title}</h2>
                <span className="mt-2 inline-block text-xs font-semibold text-primary">Open batch →</span>
              </div>
            </Link>
          ))}
        </div>
        {!list.length && (
          <p className="py-16 text-center text-sm text-muted-foreground">
            {mine.length ? "No batches found." : "No batches are assigned to your account yet. Please contact the admin."}
          </p>
        )}
      </main>
      <WhatsAppFab />
    </div>
  );
}
