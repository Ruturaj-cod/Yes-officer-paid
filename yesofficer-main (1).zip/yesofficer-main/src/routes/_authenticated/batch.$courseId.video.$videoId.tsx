import { createFileRoute, useRouter } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { ClientOnly } from "@tanstack/react-router";
import { ChevronLeft } from "lucide-react";
import { z } from "zod";
import { fetchVideoCached } from "@/lib/yoapi";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { SiteHeader, WhatsAppFab } from "@/components/SiteHeader";
import { PdfRow } from "@/components/PdfReader";
import { VideoPlayer } from "@/components/VideoPlayer";
import { useQuery } from "@tanstack/react-query";
import { meQuery, useLogAccess } from "@/lib/me";
import { canOpenBatch } from "@/lib/access";
import { NoAccess } from "@/components/NoAccess";

const videoQuery = (courseId: string, videoId: string) =>
  queryOptions({
    queryKey: ["video", courseId, videoId],
    queryFn: () => fetchVideoCached(courseId, videoId),
    staleTime: Infinity,
  });

export const Route = createFileRoute("/_authenticated/batch/$courseId/video/$videoId")({
  validateSearch: z.object({ t: z.string().optional() }),
  ssr: false,
  loader: ({ context, params }) =>
    context.queryClient.ensureQueryData(videoQuery(params.courseId, params.videoId)),
  head: ({ loaderData }) => {
    const title = loaderData?.title ? `${loaderData.title} – YES OFFICER` : "Lecture – YES OFFICER";
    return {
      meta: [
        { title },
        { name: "description", content: "Watch the lecture and read the class notes." },
        { property: "og:title", content: title },
        { property: "og:description", content: "Watch the lecture and read the class notes." },
        { property: "og:type", content: "video.other" },
        { name: "twitter:card", content: "summary" },
      ],
    };
  },
  pendingComponent: () => (
    <div className="min-h-screen"><SiteHeader /><div className="mx-auto max-w-4xl px-4 py-6"><div className="aspect-video animate-pulse rounded-2xl bg-muted" /></div></div>
  ),
  errorComponent: ({ error }) => (
    <div className="min-h-screen"><SiteHeader /><p className="p-8 text-center text-sm text-destructive">{(error as Error).message}</p></div>
  ),
  component: VideoPage,
});

function VideoPage() {
  const { courseId } = Route.useParams();
  const { data: me } = useQuery(meQuery);
  if (me && !canOpenBatch(courseId, me.courseIds, me.isAdmin)) return <NoAccess />;
  if (!me) return null;
  return <VideoView />;
}

function VideoView() {
  const { courseId, videoId } = Route.useParams();
  const { data } = useSuspenseQuery(videoQuery(courseId, videoId));
  const router = useRouter();
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const refresh = async () => {
    setBusy(true);
    try { qc.setQueryData(videoQuery(courseId, videoId).queryKey, await fetchVideoCached(courseId, videoId, true)); }
    catch (e) { alert((e as Error).message); }
    finally { setBusy(false); }
  };
  useLogAccess({ courseId, itemId: videoId, itemTitle: data.title, kind: "video" });

  return (
    <div className="min-h-screen pb-24">
      <SiteHeader />
      <main className="mx-auto max-w-4xl space-y-5 px-4 py-5">
        <button onClick={() => router.history.back()} className="flex items-center rounded-lg bg-secondary px-2 py-1 text-xs font-semibold text-secondary-foreground">
          <ChevronLeft className="h-4 w-4" /> Back
        </button>
        <ClientOnly fallback={<div className="aspect-video rounded-2xl bg-muted" />}>
          <VideoPlayer qualities={data.qualities} track={{ courseId, videoId, title: data.title }} />
        </ClientOnly>
        <button onClick={refresh} disabled={busy} className="text-xs font-semibold text-muted-foreground underline disabled:opacity-50">
          {busy ? "Refreshing…" : "Video not playing? Refresh link"}
        </button>
        <h1 className="text-lg font-extrabold leading-snug">{data.title}</h1>
        {data.pdfs.length > 0 && (
          <section className="space-y-2">
            <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Class notes</h2>
            {data.pdfs.map((p) => <PdfRow key={p.url} pdf={p} title={data.title} />)}
          </section>
        )}
      </main>
      <WhatsAppFab />
    </div>
  );
}
