# Private login, batch access control and admin panel

## What users will see
- **Login page first.** Anyone opening the site sees only a sign-in screen. There is no "Sign up" option.
- Users sign in with a **username + password** created by the owner.
- After signing in, users see **only the batches assigned to them**. Opening any other batch shows "No access".
- **One device at a time:** signing in on a new phone or laptop signs out the old one within seconds, showing the message "You were signed in on another device".
- Suspended users can't sign in and get signed out right away.

## Admin panel (`/admin`, owner only)
1. **Users:** create a user (name, username, password), suspend or reactivate them, and reset their password.
2. **Batch access:** for each user, tick the batches they can see. You can add or remove access at any time, and it takes effect immediately.
3. **Access log:** a searchable table showing who opened which batch, lecture or PDF, and when. You can filter by user, batch, content name or date range.
4. The first owner account is created from your email. I'll ask you for it while building.

## Security notes
- All checks happen on the server: assigned batches, suspended status and the current device are verified on every request, not just hidden in the page.
- The Yes Officer token is only handed out to signed-in, active users on their current device. Today anyone can get it.
- Limitation: because Yes Officer blocks our server, the browser still talks to Yes Officer directly. A technical user who is signed in could misuse the token outside the app. Normal use is fully restricted.

## Technical details
- Enable Lovable Cloud with email/password auth. Usernames map to a hidden synthetic email (`username@users.local`) and auto-confirm is on. There is no signup UI.
- Tables:
  - `profiles` (username, display_name, suspended, active_session_id)
  - `user_roles` (admin role, using a has_role security definer)
  - `batch_access` (user_id, course_id)
  - `access_logs` (user_id, course_id, item_id, item_title, kind, created_at)
  - RLS: users read only their own rows; admins read everything.
- On login, a server fn writes a new `active_session_id` to the profile, and the browser stores it. Every protected server fn (`getApiToken`, `getMyBatches`, `logAccess`) checks the session id, suspended status and batch access. A mismatch returns 401, and the client signs out with a notice. A light 30s check plus a check on focus catch old devices quickly.
- Admin server fns (`createUser`, `resetPassword`, `setSuspended`, `setBatchAccess`, `searchLogs`) verify the admin role, then use the admin client.
- Routes:
  - `/auth` (public login)
  - `_authenticated/` containing home, batch, video and admin
  - `src/routes/index.tsx` redirects to `/auth` or the home page
- The home page shows the batch list from Yes Officer, filtered to the assigned course ids.
- The local "Enroll" feature is replaced by assigned batches.
- Tests: batch-filter and session-mismatch rules.
