<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Yes Officer API is called from the browser (src/lib/yoapi.ts, routes use ssr:false); the token comes from the YESOFFICER_TOKEN secret via a server function; why: Yes Officer returns 403 to requests from the Cloudflare server runtime. If the direct browser call fails (other hosts such as Vercel), apiGet falls back to the authenticated yoProxy server fn with an endpoint allowlist.
- Video streams play through /api/public/stream, which adds the required Referer and rewrites playlists; why: the video CDN rejects requests without it.
- PDFs render in-app with pdfjs-dist (PdfReader.tsx) loading through /api/public/pdf; why: Google's viewer can't reach the app's proxy reliably and mobile browsers don't render PDFs in iframes.
- Accounts are owner-created only (public signup disabled); usernames map to synthetic emails via src/lib/access.ts; why: no public sign-up and username login.
- One-device and suspension rules compare the JWT session_id with profiles.active_session_id inside every protected server fn (src/lib/guard.server.ts); why: server-side enforcement, not just UI.
- Lecture details are read through the shared cached_content table first and saved there after a Yes Officer fetch (fetchVideoCached in src/lib/yoapi.ts); why: one fetch serves all students and avoids 429 rate limits.
- Home timetable uses one purchased-class timetable request, filters explicit course IDs against visible batches, and groups dates in Asia/Kolkata; why: avoid per-batch request bursts and show students only their assigned schedule.
- Folder lists are cached in cached_content (kind FOLDER, item_id = parent id) via fetchFolderCached: copies under 30 min skip Yes Officer, and any saved copy is served when Yes Officer fails; why: browsing and cached lectures keep working after token expiry or 429.
